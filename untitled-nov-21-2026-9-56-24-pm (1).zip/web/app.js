import {
  SKILL_OPTIONS,
  INTEREST_OPTIONS,
  BUDGET_OPTIONS,
  HOURS_OPTIONS,
  LOCATION_OPTIONS,
  TOOL_OPTIONS,
  EXPERIENCE_OPTIONS,
  getBudgetLabel
} from './engine.js';
import { analyzeWithOptionalGemini } from './gemini.js';
import {
  loadSavedPlans,
  upsertSavedPlan,
  deleteSavedPlan,
  toggleStepInSavedPlan,
  loadWizardDraft,
  saveWizardDraft,
  clearWizardDraft,
  getOptionalGeminiKey,
  setOptionalGeminiKey,
  calculatePlanProgress
} from './storage.js';

function escapeHtml(value) {
  return String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

export function createInitialProfile() {
  return {
    skills: [],
    customSkillsList: [],
    customSkills: '',
    experienceId: 'beginner',
    interests: [],
    passionNote: '',
    budgetId: 'zero',
    customBudgetYer: '',
    hoursId: '8_15',
    locationPreference: 'flexible',
    tools: ['smartphone'],
    city: ''
  };
}

export function validateWizardStep(step, profile) {
  if (step === 1) {
    const hasSkill =
      (profile.skills && profile.skills.length > 0) ||
      (profile.customSkillsList && profile.customSkillsList.length > 0);
    if (!hasSkill) {
      return 'يرجى اختيار مهارة واحدة على الأقل أو إضافة مهارة مخصصة للمتابعة.';
    }
  }
  if (step === 2) {
    const hasInterest =
      (profile.interests && profile.interests.length > 0) ||
      (profile.passionNote && profile.passionNote.trim().length > 0);
    if (!hasInterest) {
      return 'يرجى اختيار مجال اهتمام واحد على الأقل أو كتابة نبذة مختصرة.';
    }
  }
  if (step === 3) {
    if (profile.customBudgetYer !== '' && Number(profile.customBudgetYer) < 0) {
      return 'يرجى إدخال مبلغ صحيح بالريال اليمني (0 أو أكثر).';
    }
  }
  if (step === 4) {
    if (!profile.tools || profile.tools.length === 0) {
      return 'يرجى تحديد أداة واحدة متوفرة لديك على الأقل (مثل الهاتف الذكي).';
    }
  }
  return '';
}

export function initKhatwatApp() {
  const state = {
    currentView: 'landing',
    wizardStep: 1,
    profile: createInitialProfile(),
    currentPlan: null,
    selectedIdeaId: null,
    detailTab: 'steps',
    savedPlans: loadSavedPlans(),
    deferredInstallPrompt: null,
    useOptionalGemini: false,
    optionalGeminiKey: getOptionalGeminiKey(),
    toastTimer: null
  };

  // DOM References
  const views = {
    landing: document.getElementById('view-landing'),
    wizard: document.getElementById('view-wizard'),
    loading: document.getElementById('view-loading'),
    results: document.getElementById('view-results'),
    detail: document.getElementById('view-detail'),
    saved: document.getElementById('view-saved')
  };

  const els = {
    savedCountBadge: document.getElementById('saved-count-badge'),
    statusDot: document.getElementById('status-dot'),
    statusText: document.getElementById('status-text'),
    btnInstallTop: document.getElementById('btn-install-top'),
    btnInstallPwa: document.getElementById('btn-install-pwa'),
    btnResumeDraft: document.getElementById('btn-resume-draft'),
    wizardStepLabel: document.getElementById('wizard-step-label'),
    wizardStepPercent: document.getElementById('wizard-step-percent'),
    wizardProgressFill: document.getElementById('wizard-progress-fill'),
    wizardErrorBox: document.getElementById('wizard-error-box'),
    btnWizardPrev: document.getElementById('btn-wizard-prev'),
    btnWizardNext: document.getElementById('btn-wizard-next'),
    btnWizardSubmit: document.getElementById('btn-wizard-submit'),
    skillsChips: document.getElementById('skills-chips'),
    inputCustomSkill: document.getElementById('input-custom-skill'),
    customSkillsTags: document.getElementById('custom-skills-tags'),
    experienceOptions: document.getElementById('experience-options'),
    interestsChips: document.getElementById('interests-chips'),
    inputPassionNote: document.getElementById('input-passion-note'),
    budgetOptions: document.getElementById('budget-options'),
    inputCustomBudget: document.getElementById('input-custom-budget'),
    hoursOptions: document.getElementById('hours-options'),
    locationOptions: document.getElementById('location-options'),
    toolsChips: document.getElementById('tools-chips'),
    inputCity: document.getElementById('input-city'),
    chkUseGemini: document.getElementById('chk-use-gemini'),
    inputGeminiKey: document.getElementById('input-gemini-key'),
    resultsProfileSummary: document.getElementById('results-profile-summary'),
    resultsSourcePill: document.getElementById('results-source-pill'),
    resultsFallbackNotice: document.getElementById('results-fallback-notice'),
    resultsDisclaimerText: document.getElementById('results-disclaimer-text'),
    ideasList: document.getElementById('ideas-list'),
    btnSavePlan: document.getElementById('btn-save-plan'),
    detailModeBadge: document.getElementById('detail-mode-badge'),
    detailTitle: document.getElementById('detail-title'),
    detailSummary: document.getElementById('detail-summary'),
    detailStepsProgressLabel: document.getElementById('detail-steps-progress-label'),
    detailStepsProgressFill: document.getElementById('detail-steps-progress-fill'),
    detailStepsList: document.getElementById('detail-steps-list'),
    finStartupRange: document.getElementById('fin-startup-range'),
    finMonthlyRevenue: document.getElementById('fin-monthly-revenue'),
    finMonthlyExpense: document.getElementById('fin-monthly-expense'),
    finBreakEven: document.getElementById('fin-break-even'),
    finItemsList: document.getElementById('fin-items-list'),
    finDisclaimer: document.getElementById('fin-disclaimer'),
    mktAudience: document.getElementById('mkt-audience'),
    mktChannels: document.getElementById('mkt-channels'),
    mktFirstWeek: document.getElementById('mkt-first-week'),
    mktPricingTip: document.getElementById('mkt-pricing-tip'),
    savedPlansList: document.getElementById('saved-plans-list'),
    modalRevise: document.getElementById('modal-revise'),
    inputReviseNote: document.getElementById('input-revise-note'),
    modalInstallHelp: document.getElementById('modal-install-help'),
    toast: document.getElementById('toast')
  };

  function showToast(message) {
    if (!els.toast) return;
    els.toast.textContent = message;
    els.toast.classList.remove('hidden');
    if (state.toastTimer) clearTimeout(state.toastTimer);
    state.toastTimer = setTimeout(() => {
      els.toast.classList.add('hidden');
    }, 3200);
  }

  function updateConnectivityStrip() {
    const online = typeof navigator === 'undefined' ? true : navigator.onLine !== false;
    if (els.statusDot && els.statusText) {
      els.statusDot.classList.toggle('offline', !online);
      els.statusText.textContent = online
        ? 'الوضع المحلي المجاني 100% — متصل وجاهز للعمل دون إنترنت'
        : 'أنت غير متصل بالإنترنت — المحرك المحلي والتخزين يعملان بكفاءة كاملة';
    }
  }

  function updateSavedCountBadge() {
    state.savedPlans = loadSavedPlans();
    if (els.savedCountBadge) {
      els.savedCountBadge.textContent = String(state.savedPlans.length);
    }
  }

  function switchView(viewName) {
    state.currentView = viewName;
    Object.entries(views).forEach(([key, section]) => {
      if (section) {
        section.classList.toggle('hidden', key !== viewName);
      }
    });
    if (typeof window !== 'undefined' && typeof window.scrollTo === 'function') {
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  }

  function renderDraftButton() {
    const draft = loadWizardDraft();
    if (els.btnResumeDraft) {
      els.btnResumeDraft.classList.toggle('hidden', !draft);
    }
  }

  function syncDraft() {
    const profileToSave = {
      ...state.profile,
      customSkills: state.profile.customSkillsList.join('، ')
    };
    state.profile.customSkills = profileToSave.customSkills;
    saveWizardDraft(profileToSave);
  }

  function renderWizard() {
    const stepTitles = {
      1: 'الخطوة 1 من 4: المهارات والخبرات',
      2: 'الخطوة 2 من 4: الاهتمامات والمجالات',
      3: 'الخطوة 3 من 4: الميزانية (YER) والوقت',
      4: 'الخطوة 4 من 4: بيئة العمل والأدوات'
    };

    const pct = state.wizardStep * 25;
    els.wizardStepLabel.textContent = stepTitles[state.wizardStep];
    els.wizardStepPercent.textContent = `${pct}%`;
    els.wizardProgressFill.style.width = `${pct}%`;

    [1, 2, 3, 4].forEach((n) => {
      const panel = document.getElementById(`wizard-step-${n}`);
      if (panel) panel.classList.toggle('hidden', n !== state.wizardStep);
    });

    els.btnWizardPrev.disabled = state.wizardStep === 1;
    els.btnWizardNext.classList.toggle('hidden', state.wizardStep === 4);
    els.btnWizardSubmit.classList.toggle('hidden', state.wizardStep !== 4);
    els.wizardErrorBox.classList.add('hidden');

    // Step 1 chips
    els.skillsChips.innerHTML = '';
    SKILL_OPTIONS.forEach((opt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `chip-btn ${state.profile.skills.includes(opt.id) ? 'selected' : ''}`;
      btn.textContent = opt.label;
      btn.addEventListener('click', () => {
        const idx = state.profile.skills.indexOf(opt.id);
        if (idx >= 0) state.profile.skills.splice(idx, 1);
        else state.profile.skills.push(opt.id);
        syncDraft();
        renderWizard();
      });
      els.skillsChips.appendChild(btn);
    });

    // Custom skill tags
    els.customSkillsTags.innerHTML = '';
    state.profile.customSkillsList.forEach((skillName, index) => {
      const tag = document.createElement('button');
      tag.type = 'button';
      tag.className = 'chip-btn selected-orange';
      tag.textContent = `${skillName} ×`;
      tag.addEventListener('click', () => {
        state.profile.customSkillsList.splice(index, 1);
        syncDraft();
        renderWizard();
      });
      els.customSkillsTags.appendChild(tag);
    });

    // Experience cards
    els.experienceOptions.innerHTML = '';
    EXPERIENCE_OPTIONS.forEach((opt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `option-card ${state.profile.experienceId === opt.id ? 'selected' : ''}`;
      btn.innerHTML = `<strong>${opt.label}</strong><span>${opt.hint}</span>`;
      btn.addEventListener('click', () => {
        state.profile.experienceId = opt.id;
        syncDraft();
        renderWizard();
      });
      els.experienceOptions.appendChild(btn);
    });

    // Step 2 interests
    els.interestsChips.innerHTML = '';
    INTEREST_OPTIONS.forEach((opt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `chip-btn ${state.profile.interests.includes(opt.id) ? 'selected' : ''}`;
      btn.textContent = opt.label;
      btn.addEventListener('click', () => {
        const idx = state.profile.interests.indexOf(opt.id);
        if (idx >= 0) state.profile.interests.splice(idx, 1);
        else state.profile.interests.push(opt.id);
        syncDraft();
        renderWizard();
      });
      els.interestsChips.appendChild(btn);
    });
    if (els.inputPassionNote.value !== state.profile.passionNote) {
      els.inputPassionNote.value = state.profile.passionNote;
    }

    // Step 3 budget & hours
    els.budgetOptions.innerHTML = '';
    BUDGET_OPTIONS.forEach((opt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      const isSelected = state.profile.budgetId === opt.id && state.profile.customBudgetYer === '';
      btn.className = `option-card ${isSelected ? 'selected' : ''}`;
      btn.innerHTML = `<strong>${opt.label}</strong><span>${opt.hint}</span>`;
      btn.addEventListener('click', () => {
        state.profile.budgetId = opt.id;
        state.profile.customBudgetYer = '';
        els.inputCustomBudget.value = '';
        syncDraft();
        renderWizard();
      });
      els.budgetOptions.appendChild(btn);
    });
    if (els.inputCustomBudget.value !== String(state.profile.customBudgetYer || '')) {
      els.inputCustomBudget.value = state.profile.customBudgetYer || '';
    }

    els.hoursOptions.innerHTML = '';
    HOURS_OPTIONS.forEach((opt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `option-card ${state.profile.hoursId === opt.id ? 'selected' : ''}`;
      btn.innerHTML = `<strong>${opt.label}</strong><span>${opt.hint}</span>`;
      btn.addEventListener('click', () => {
        state.profile.hoursId = opt.id;
        syncDraft();
        renderWizard();
      });
      els.hoursOptions.appendChild(btn);
    });

    // Step 4 location & tools
    els.locationOptions.innerHTML = '';
    LOCATION_OPTIONS.forEach((opt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `option-card ${state.profile.locationPreference === opt.id ? 'selected' : ''}`;
      btn.innerHTML = `<strong>${opt.label}</strong><span>${opt.hint}</span>`;
      btn.addEventListener('click', () => {
        state.profile.locationPreference = opt.id;
        syncDraft();
        renderWizard();
      });
      els.locationOptions.appendChild(btn);
    });

    els.toolsChips.innerHTML = '';
    TOOL_OPTIONS.forEach((opt) => {
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.className = `chip-btn ${state.profile.tools.includes(opt.id) ? 'selected' : ''}`;
      btn.textContent = opt.label;
      btn.addEventListener('click', () => {
        const idx = state.profile.tools.indexOf(opt.id);
        if (idx >= 0) state.profile.tools.splice(idx, 1);
        else state.profile.tools.push(opt.id);
        syncDraft();
        renderWizard();
      });
      els.toolsChips.appendChild(btn);
    });

    if (els.inputCity.value !== state.profile.city) {
      els.inputCity.value = state.profile.city;
    }
    els.chkUseGemini.checked = state.useOptionalGemini;
    els.inputGeminiKey.value = state.optionalGeminiKey;
  }

  function renderResults() {
    const plan = state.currentPlan;
    if (!plan) return;

    const locLabel =
      LOCATION_OPTIONS.find((l) => l.id === plan.profile.locationPreference)?.label || 'مرن';
    els.resultsProfileSummary.textContent = `الميزانية: ${getBudgetLabel(plan.profile)} · العمل: ${locLabel}${plan.revisionNote ? ` · التعديل: ${plan.revisionNote}` : ''}`;
    els.resultsSourcePill.textContent = plan.sourceLabel;
    els.resultsDisclaimerText.textContent = plan.disclaimer;

    if (plan.fallbackNotice) {
      els.resultsFallbackNotice.textContent = plan.fallbackNotice;
      els.resultsFallbackNotice.classList.remove('hidden');
    } else {
      els.resultsFallbackNotice.classList.add('hidden');
    }

    const isAlreadySaved = state.savedPlans.some((p) => p.id === plan.id);
    els.btnSavePlan.textContent = isAlreadySaved ? 'محفوظة في خططي ✓' : 'حفظ في خططي';

    els.ideasList.innerHTML = '';
    plan.ideas.forEach((idea) => {
      const card = document.createElement('article');
      card.className = 'idea-card';

      const reasonsHtml = idea.reasons.map((r) => `<li>${escapeHtml(r)}</li>`).join('');
      const doneSteps = idea.steps.filter((s) => s.completed).length;

      card.innerHTML = `
        <div class="idea-card-top">
          <span class="idea-rank-badge">الفكرة #${idea.rank}</span>
          <span class="idea-mode-badge">${escapeHtml(idea.workModeLabel)}</span>
        </div>
        <h3 class="idea-title">${escapeHtml(idea.title)}</h3>
        <p class="idea-summary">${escapeHtml(idea.summary)}</p>
        <div class="reasons-box">
          <h4>لماذا تناسبك هذه الفكرة؟</h4>
          <ul class="reasons-list">${reasonsHtml}</ul>
        </div>
        <div class="metrics-row">
          <div class="metric-tile">
            <span>التكلفة التأسيسية التقديرية</span>
            <strong>${escapeHtml(idea.financials.startupRangeLabel)}</strong>
          </div>
          <div class="metric-tile">
            <span>العائد الشهري التقديري (غير مضمون)</span>
            <strong>${escapeHtml(idea.financials.monthlyRevenue)}</strong>
          </div>
        </div>
        <button class="btn btn-primary btn-full" type="button" data-open-idea="${escapeHtml(idea.id)}">
          عرض خطة التنفيذ والتسويق (${doneSteps}/${idea.steps.length} خطوات)
        </button>
      `;

      const openBtn = card.querySelector('[data-open-idea]');
      openBtn.addEventListener('click', () => {
        state.selectedIdeaId = idea.id;
        state.detailTab = 'steps';
        renderDetail();
        switchView('detail');
      });

      els.ideasList.appendChild(card);
    });
  }

  function renderDetail() {
    const plan = state.currentPlan;
    if (!plan) return;
    const idea = plan.ideas.find((i) => i.id === state.selectedIdeaId) || plan.ideas[0];
    if (!idea) return;
    state.selectedIdeaId = idea.id;

    els.detailModeBadge.textContent = idea.workModeLabel;
    els.detailTitle.textContent = idea.title;
    els.detailSummary.textContent = idea.summary;

    // Tabs state
    document.querySelectorAll('.tab-btn').forEach((btn) => {
      btn.classList.toggle('active', btn.dataset.tab === state.detailTab);
    });
    document.getElementById('detail-tab-steps').classList.toggle('hidden', state.detailTab !== 'steps');
    document.getElementById('detail-tab-financials').classList.toggle('hidden', state.detailTab !== 'financials');
    document.getElementById('detail-tab-marketing').classList.toggle('hidden', state.detailTab !== 'marketing');

    // Steps checklist
    const total = idea.steps.length;
    const done = idea.steps.filter((s) => s.completed).length;
    const pct = total > 0 ? Math.round((done / total) * 100) : 0;
    els.detailStepsProgressLabel.textContent = `${done}/${total} (${pct}%)`;
    els.detailStepsProgressFill.style.width = `${pct}%`;

    els.detailStepsList.innerHTML = '';
    idea.steps.forEach((step, idx) => {
      const label = document.createElement('label');
      label.className = `step-item ${step.completed ? 'completed' : ''}`;
      label.innerHTML = `
        <input class="step-checkbox" type="checkbox" ${step.completed ? 'checked' : ''} />
        <div class="step-body">
          <div class="step-header">
            <span class="step-title">${idx + 1}. ${escapeHtml(step.title)}</span>
            <span class="step-time">${escapeHtml(step.timeframe)}</span>
          </div>
          <p class="step-desc">${escapeHtml(step.description)}</p>
        </div>
      `;

      const checkbox = label.querySelector('.step-checkbox');
      checkbox.addEventListener('change', () => {
        step.completed = checkbox.checked;
        // Persist in localStorage if plan is saved (or auto-save update)
        const existingSaved = state.savedPlans.some((p) => p.id === plan.id);
        if (existingSaved) {
          toggleStepInSavedPlan(plan.id, idea.id, step.id);
          updateSavedCountBadge();
        } else {
          upsertSavedPlan(plan);
          updateSavedCountBadge();
          showToast('تم حفظ الخطة وتقدم الخطوة محلياً.');
        }
        renderDetail();
      });

      els.detailStepsList.appendChild(label);
    });

    // Financials tab
    els.finStartupRange.textContent = idea.financials.startupRangeLabel;
    els.finMonthlyRevenue.textContent = idea.financials.monthlyRevenue;
    els.finMonthlyExpense.textContent = idea.financials.monthlyExpense;
    els.finBreakEven.textContent = idea.financials.breakEven;
    els.finDisclaimer.textContent = idea.financials.disclaimer;

    els.finItemsList.innerHTML = '';
    idea.financials.startupItems.forEach((row) => {
      const div = document.createElement('div');
      div.className = 'cost-row';
      div.innerHTML = `<span>${escapeHtml(row.item)}</span><strong>${escapeHtml(row.range)}</strong>`;
      els.finItemsList.appendChild(div);
    });

    // Marketing tab
    els.mktAudience.textContent = idea.marketing.targetAudience;
    els.mktChannels.innerHTML = idea.marketing.channels
      .map((ch) => `<li>${escapeHtml(ch)}</li>`)
      .join('');
    els.mktFirstWeek.textContent = idea.marketing.firstWeekActions;
    els.mktPricingTip.textContent = idea.marketing.pricingTip;
  }

  function renderSavedPlans() {
    state.savedPlans = loadSavedPlans();
    updateSavedCountBadge();
    els.savedPlansList.innerHTML = '';

    if (state.savedPlans.length === 0) {
      els.savedPlansList.innerHTML = `
        <div class="card" style="text-align: center; padding: 32px 18px">
          <div style="font-size: 2rem; margin-bottom: 8px">📂</div>
          <h3 style="margin: 0 0 6px; color: var(--navy-900)">لا توجد خطط محفوظة بعد</h3>
          <p style="margin: 0 0 16px; color: var(--text-secondary); font-size: 0.9rem">
            أكمل استبيان خطوتك لتحصل على 3 مشاريع مخصصة وتُحفظ هنا للرجوع إليها دون إنترنت.
          </p>
          <button id="btn-empty-saved-start" class="btn btn-primary" type="button">ابدأ الاستبيان الآن</button>
        </div>
      `;
      const emptyBtn = document.getElementById('btn-empty-saved-start');
      if (emptyBtn) {
        emptyBtn.addEventListener('click', () => startFreshWizard());
      }
      return;
    }

    state.savedPlans.forEach((plan) => {
      const progress = calculatePlanProgress(plan);
      const dateStr = new Date(plan.createdAt || Date.now()).toLocaleDateString('ar-YE', {
        year: 'numeric',
        month: 'short',
        day: 'numeric'
      });
      const firstTitle = plan.ideas?.[0]?.title || 'خطة مشاريع';

      const card = document.createElement('article');
      card.className = 'saved-card';
      card.innerHTML = `
        <div class="idea-card-top">
          <span class="idea-rank-badge">${escapeHtml(dateStr)}</span>
          <span class="idea-mode-badge">الإنجاز ${progress.percent}%</span>
        </div>
        <h3 class="idea-title">${escapeHtml(firstTitle)} (+2 أفكار)</h3>
        <p class="idea-summary">الميزانية: ${escapeHtml(getBudgetLabel(plan.profile))} · ${progress.done} من ${progress.total} خطوة مكتملة</p>
        <div class="progress-track">
          <div class="progress-fill" style="width: ${progress.percent}%"></div>
        </div>
        <div class="saved-card-actions">
          <button class="btn btn-navy" type="button" data-open-saved="${escapeHtml(plan.id)}">فتح الخطة</button>
          <button class="btn btn-danger-outline" type="button" data-delete-saved="${escapeHtml(plan.id)}">حذف</button>
        </div>
      `;

      card.querySelector('[data-open-saved]').addEventListener('click', () => {
        state.currentPlan = plan;
        renderResults();
        switchView('results');
      });

      card.querySelector('[data-delete-saved]').addEventListener('click', () => {
        deleteSavedPlan(plan.id);
        renderSavedPlans();
        showToast('تم حذف الخطة من الجهاز.');
      });

      els.savedPlansList.appendChild(card);
    });
  }

  async function runAnalysis(revisionNote = '') {
    switchView('loading');
    const analysis = await analyzeWithOptionalGemini(state.profile, revisionNote, {
      apiKey: state.optionalGeminiKey,
      useOptionalGemini: state.useOptionalGemini
    });

    const bundle = {
      id: `plan_${Date.now()}`,
      createdAt: Date.now(),
      updatedAt: Date.now(),
      profile: JSON.parse(JSON.stringify(state.profile)),
      ...analysis
    };

    state.currentPlan = bundle;
    upsertSavedPlan(bundle);
    clearWizardDraft();
    renderDraftButton();
    updateSavedCountBadge();
    renderResults();
    switchView('results');
    showToast('تم إنشاء 3 أفكار مشاريع وحفظها محلياً على جهازك.');
  }

  function startFreshWizard() {
    state.profile = createInitialProfile();
    state.wizardStep = 1;
    renderWizard();
    switchView('wizard');
  }

  // Bind Landing & Topbar buttons
  document.getElementById('btn-brand-home').addEventListener('click', () => {
    renderDraftButton();
    switchView('landing');
  });

  document.getElementById('btn-start-wizard').addEventListener('click', () => {
    startFreshWizard();
  });

  els.btnResumeDraft.addEventListener('click', () => {
    const draft = loadWizardDraft();
    if (draft) {
      state.profile = { ...createInitialProfile(), ...draft };
      state.wizardStep = 1;
      renderWizard();
      switchView('wizard');
    }
  });

  document.getElementById('btn-open-saved').addEventListener('click', () => {
    renderSavedPlans();
    switchView('saved');
  });

  document.getElementById('btn-nav-saved').addEventListener('click', () => {
    renderSavedPlans();
    switchView('saved');
  });

  document.getElementById('btn-saved-new').addEventListener('click', () => {
    startFreshWizard();
  });

  // Bind Wizard controls
  document.getElementById('btn-add-skill').addEventListener('click', () => {
    const val = els.inputCustomSkill.value.trim();
    if (!val) return;
    if (!state.profile.customSkillsList.includes(val)) {
      state.profile.customSkillsList.push(val);
    }
    els.inputCustomSkill.value = '';
    syncDraft();
    renderWizard();
  });

  els.inputCustomSkill.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      e.preventDefault();
      document.getElementById('btn-add-skill').click();
    }
  });

  els.inputPassionNote.addEventListener('input', (e) => {
    state.profile.passionNote = e.target.value;
    syncDraft();
  });

  els.inputCustomBudget.addEventListener('input', (e) => {
    state.profile.customBudgetYer = e.target.value;
    syncDraft();
    renderWizard();
  });

  els.inputCity.addEventListener('input', (e) => {
    state.profile.city = e.target.value;
    syncDraft();
  });

  els.chkUseGemini.addEventListener('change', (e) => {
    state.useOptionalGemini = e.target.checked;
  });

  els.inputGeminiKey.addEventListener('input', (e) => {
    state.optionalGeminiKey = e.target.value.trim();
    setOptionalGeminiKey(state.optionalGeminiKey);
  });

  els.btnWizardPrev.addEventListener('click', () => {
    if (state.wizardStep > 1) {
      state.wizardStep -= 1;
      renderWizard();
    }
  });

  els.btnWizardNext.addEventListener('click', () => {
    const err = validateWizardStep(state.wizardStep, state.profile);
    if (err) {
      els.wizardErrorBox.textContent = err;
      els.wizardErrorBox.classList.remove('hidden');
      return;
    }
    if (state.wizardStep < 4) {
      state.wizardStep += 1;
      renderWizard();
    }
  });

  els.btnWizardSubmit.addEventListener('click', async () => {
    const err = validateWizardStep(4, state.profile);
    if (err) {
      els.wizardErrorBox.textContent = err;
      els.wizardErrorBox.classList.remove('hidden');
      return;
    }
    await runAnalysis('');
  });

  // Bind Results & Detail controls
  els.btnSavePlan.addEventListener('click', () => {
    if (!state.currentPlan) return;
    upsertSavedPlan(state.currentPlan);
    updateSavedCountBadge();
    renderResults();
    showToast('تم حفظ الخطة في ذاكرة جهازك للعمل دون إنترنت.');
  });

  document.getElementById('btn-new-analysis').addEventListener('click', () => {
    startFreshWizard();
  });

  document.getElementById('btn-detail-back').addEventListener('click', () => {
    renderResults();
    switchView('results');
  });

  document.getElementById('btn-print-plan').addEventListener('click', () => {
    if (typeof window !== 'undefined' && typeof window.print === 'function') {
      window.print();
    }
  });

  document.querySelectorAll('.tab-btn').forEach((btn) => {
    btn.addEventListener('click', () => {
      state.detailTab = btn.dataset.tab;
      renderDetail();
    });
  });

  // Revise Plan Modal
  function openReviseModal() {
    els.inputReviseNote.value = '';
    els.modalRevise.classList.remove('hidden');
  }

  document.getElementById('btn-revise-plan').addEventListener('click', openReviseModal);
  document.getElementById('btn-detail-revise').addEventListener('click', openReviseModal);
  document.getElementById('btn-close-revise').addEventListener('click', () => {
    els.modalRevise.classList.add('hidden');
  });

  document.querySelectorAll('#revise-quick-chips .chip-btn').forEach((chip) => {
    chip.addEventListener('click', () => {
      els.inputReviseNote.value = chip.dataset.note || chip.textContent;
    });
  });

  document.getElementById('btn-revise-apply').addEventListener('click', async () => {
    const note = els.inputReviseNote.value.trim();
    els.modalRevise.classList.add('hidden');
    await runAnalysis(note);
  });

  document.getElementById('btn-revise-edit-answers').addEventListener('click', () => {
    els.modalRevise.classList.add('hidden');
    if (state.currentPlan?.profile) {
      state.profile = JSON.parse(JSON.stringify(state.currentPlan.profile));
    }
    state.wizardStep = 1;
    renderWizard();
    switchView('wizard');
  });

  // PWA Install Handling
  async function handleInstallClick() {
    if (state.deferredInstallPrompt) {
      state.deferredInstallPrompt.prompt();
      const result = await state.deferredInstallPrompt.userChoice;
      if (result?.outcome === 'accepted') {
        showToast('تم تثبيت تطبيق خطوتك على جهازك!');
        els.btnInstallTop.classList.add('hidden');
      }
      state.deferredInstallPrompt = null;
    } else {
      els.modalInstallHelp.classList.remove('hidden');
    }
  }

  els.btnInstallPwa.addEventListener('click', handleInstallClick);
  els.btnInstallTop.addEventListener('click', handleInstallClick);
  document.getElementById('btn-close-install-help').addEventListener('click', () => {
    els.modalInstallHelp.classList.add('hidden');
  });
  document.getElementById('btn-install-help-ok').addEventListener('click', () => {
    els.modalInstallHelp.classList.add('hidden');
  });

  if (typeof window !== 'undefined') {
    window.addEventListener('beforeinstallprompt', (e) => {
      e.preventDefault();
      state.deferredInstallPrompt = e;
      els.btnInstallTop.classList.remove('hidden');
    });

    window.addEventListener('appinstalled', () => {
      state.deferredInstallPrompt = null;
      els.btnInstallTop.classList.add('hidden');
      showToast('أهلاً بك! تم تثبيت خطوتك كتطبيق على هاتفك.');
    });

    window.addEventListener('online', updateConnectivityStrip);
    window.addEventListener('offline', updateConnectivityStrip);

    if ('serviceWorker' in navigator) {
      navigator.serviceWorker.register('./sw.js').catch(() => {
        // Ignore if opened via file:// during local preview
      });
    }
  }

  // Initial render
  updateConnectivityStrip();
  updateSavedCountBadge();
  renderDraftButton();
  renderWizard();

  return { state, switchView, runAnalysis };
}

if (
  typeof document !== 'undefined' &&
  typeof window !== 'undefined' &&
  !window.__KHATWAT_TEST_MODE__ &&
  document.getElementById('view-landing')
) {
  initKhatwatApp();
}
