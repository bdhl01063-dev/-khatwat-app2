import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import {
  analyzeProfileLocally,
  FINANCIAL_DISCLAIMER_AR,
  getBudgetMaxYer,
  getBudgetLabel
} from '../engine.js';
import { analyzeWithOptionalGemini } from '../gemini.js';
import {
  loadSavedPlans,
  upsertSavedPlan,
  deleteSavedPlan,
  toggleStepInSavedPlan,
  saveWizardDraft,
  loadWizardDraft,
  clearWizardDraft,
  calculatePlanProgress
} from '../storage.js';
import { createInitialProfile, validateWizardStep } from '../app.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WEB_DIR = path.resolve(__dirname, '..');

function createMemoryStorage() {
  const map = new Map();
  return {
    getItem: (k) => (map.has(k) ? map.get(k) : null),
    setItem: (k, v) => map.set(k, String(v)),
    removeItem: (k) => map.delete(k)
  };
}

test('PWA manifest and offline assets exist and are valid Arabic RTL', () => {
  const manifestPath = path.join(WEB_DIR, 'manifest.webmanifest');
  const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf8'));

  assert.equal(manifest.lang, 'ar');
  assert.equal(manifest.dir, 'rtl');
  assert.equal(manifest.display, 'standalone');
  assert.equal(manifest.theme_color, '#0F1E36');
  assert.ok(Array.isArray(manifest.icons) && manifest.icons.length >= 3);

  for (const icon of manifest.icons) {
    const iconFile = path.join(WEB_DIR, icon.src.replace('./', ''));
    assert.ok(fs.existsSync(iconFile), `Missing icon file: ${icon.src}`);
    assert.ok(fs.statSync(iconFile).size > 100, `Icon file too small: ${icon.src}`);
  }

  const swContent = fs.readFileSync(path.join(WEB_DIR, 'sw.js'), 'utf8');
  assert.ok(swContent.includes('./index.html'));
  assert.ok(swContent.includes('./engine.js'));
  assert.ok(swContent.includes('./storage.js'));
  assert.ok(swContent.includes('./app.js'));
});

test('HTML contains all essential interactive button IDs and RTL attributes', () => {
  const html = fs.readFileSync(path.join(WEB_DIR, 'index.html'), 'utf8');
  assert.ok(html.includes('<html lang="ar" dir="rtl">'));
  assert.ok(html.includes('manifest.webmanifest'));

  const requiredIds = [
    'btn-brand-home',
    'btn-nav-saved',
    'btn-start-wizard',
    'btn-open-saved',
    'btn-install-pwa',
    'btn-add-skill',
    'btn-wizard-prev',
    'btn-wizard-next',
    'btn-wizard-submit',
    'btn-revise-plan',
    'btn-save-plan',
    'btn-new-analysis',
    'btn-detail-back',
    'btn-detail-revise',
    'btn-print-plan',
    'tab-btn-steps',
    'tab-btn-financials',
    'tab-btn-marketing',
    'btn-revise-apply',
    'btn-revise-edit-answers',
    'btn-saved-new'
  ];

  for (const id of requiredIds) {
    assert.ok(html.includes(`id="${id}"`), `Missing HTML element id="${id}"`);
  }
});

test('Wizard validation catches missing inputs and passes when valid', () => {
  const profile = createInitialProfile();
  assert.ok(validateWizardStep(1, profile).length > 0);
  profile.skills.push('design');
  assert.equal(validateWizardStep(1, profile), '');

  assert.ok(validateWizardStep(2, profile).length > 0);
  profile.interests.push('digital_services');
  assert.equal(validateWizardStep(2, profile), '');

  profile.customBudgetYer = '-500';
  assert.ok(validateWizardStep(3, profile).length > 0);
  profile.customBudgetYer = '25000';
  assert.equal(validateWizardStep(3, profile), '');

  profile.tools = [];
  assert.ok(validateWizardStep(4, profile).length > 0);
  profile.tools = ['smartphone'];
  assert.equal(validateWizardStep(4, profile), '');
});

test('Local engine recommends 3 zero-capital remote ideas in YER with non-guarantee disclaimer', () => {
  const profile = {
    ...createInitialProfile(),
    skills: ['social_media', 'writing', 'design'],
    interests: ['digital_services', 'creative_media'],
    budgetId: 'zero',
    hoursId: '8_15',
    locationPreference: 'remote',
    tools: ['smartphone', 'internet'],
    city: 'صنعاء'
  };

  const result = analyzeProfileLocally(profile);
  assert.equal(result.source, 'local');
  assert.equal(result.ideas.length, 3);
  assert.equal(result.disclaimer, FINANCIAL_DISCLAIMER_AR);

  const ids = new Set(result.ideas.map((i) => i.title));
  assert.equal(ids.size, 3, 'All 3 suggested ideas must be distinct');

  for (const idea of result.ideas) {
    assert.ok(idea.reasons.length >= 2);
    assert.ok(idea.steps.length >= 3);
    assert.ok(idea.financials.startupRangeLabel.includes('ر.ي'));
    assert.ok(idea.financials.monthlyRevenue.includes('ر.ي'));
    assert.ok(idea.financials.disclaimer.includes('ليست أرباحاً مضمونة'));
    assert.ok(idea.marketing.channels.length >= 2);
    assert.ok(idea.marketing.targetAudience.includes('صنعاء'));
  }
});

test('Local engine respects home workspace, cooking skill, and YER budget', () => {
  const profile = {
    ...createInitialProfile(),
    skills: ['cooking', 'photography'],
    interests: ['food_beverage'],
    budgetId: 'micro',
    customBudgetYer: '45000',
    locationPreference: 'home',
    tools: ['smartphone', 'workspace']
  };

  assert.equal(getBudgetMaxYer(profile), 45000);
  assert.ok(getBudgetLabel(profile).includes('45,000'));

  const result = analyzeProfileLocally(profile);
  assert.equal(result.ideas.length, 3);
  assert.ok(
    result.ideas[0].title.includes('الحلويات') || result.ideas[0].title.includes('المعجنات'),
    `Expected home bakery top recommendation, got: ${result.ideas[0].title}`
  );
});

test('Revise note dynamically shifts recommendations toward phone-only & remote low cost', () => {
  const profile = {
    ...createInitialProfile(),
    skills: ['programming', 'writing', 'social_media'],
    interests: ['digital_services'],
    budgetId: 'starter',
    locationPreference: 'flexible',
    tools: ['smartphone', 'laptop', 'internet']
  };

  const revised = analyzeProfileLocally(
    profile,
    'أريد أفكاراً بالهاتف فقط وعن بُعد وأقل تكلفة مع تسويق عبر واتساب'
  );

  assert.equal(revised.ideas.length, 3);
  assert.ok(revised.revisionNote.includes('الهاتف فقط'));
  assert.ok(
    revised.ideas.every((idea) => !idea.title.includes('صفحات هبوط')),
    'Laptop-required web dev idea should not rank top when user specifies phone-only'
  );
  assert.ok(
    revised.ideas[0].marketing.channels.some((c) => c.includes('واتساب')),
    'Marketing plan should prioritize WhatsApp when requested'
  );
});

test('Optional Gemini never blocks or fails when disabled, offline, or returning HTTP error', async () => {
  const profile = {
    ...createInitialProfile(),
    skills: ['design'],
    interests: ['creative_media'],
    tools: ['smartphone']
  };

  // Case 1: Disabled (default)
  const localOnly = await analyzeWithOptionalGemini(profile, '', {
    useOptionalGemini: false,
    apiKey: ''
  });
  assert.equal(localOnly.source, 'local');
  assert.equal(localOnly.ideas.length, 3);

  // Case 2: Enabled but network/API fails -> silent clean fallback
  const fallbackResult = await analyzeWithOptionalGemini(profile, '', {
    useOptionalGemini: true,
    apiKey: 'fake-test-key',
    fetchFn: async () => {
      throw new Error('Network unavailable');
    }
  });
  assert.equal(fallbackResult.source, 'local');
  assert.equal(fallbackResult.ideas.length, 3);
  assert.ok(fallbackResult.fallbackNotice.length > 0);
});

test('LocalStorage persistence handles saving, step toggling, draft recovery, and deletion', () => {
  const store = createMemoryStorage();
  const profile = {
    ...createInitialProfile(),
    skills: ['crafts'],
    interests: ['handmade'],
    budgetId: 'micro',
    tools: ['smartphone']
  };

  // Wizard draft persistence
  saveWizardDraft(profile, store);
  const loadedDraft = loadWizardDraft(store);
  assert.deepEqual(loadedDraft.skills, ['crafts']);
  clearWizardDraft(store);
  assert.equal(loadWizardDraft(store), null);

  // Plan bundle persistence & checklist toggle
  const analysis = analyzeProfileLocally(profile);
  const bundle = {
    id: 'plan_test_1',
    createdAt: 1700000000000,
    profile,
    ...analysis
  };

  upsertSavedPlan(bundle, store);
  let plans = loadSavedPlans(store);
  assert.equal(plans.length, 1);
  assert.equal(calculatePlanProgress(plans[0]).done, 0);

  const firstIdea = plans[0].ideas[0];
  const firstStep = firstIdea.steps[0];
  const updatedPlan = toggleStepInSavedPlan('plan_test_1', firstIdea.id, firstStep.id, store);
  assert.ok(updatedPlan);
  assert.equal(updatedPlan.ideas[0].steps[0].completed, true);
  assert.equal(calculatePlanProgress(updatedPlan).done, 1);

  // Verify persistence across reload
  const reloadedPlans = loadSavedPlans(store);
  assert.equal(reloadedPlans[0].ideas[0].steps[0].completed, true);

  // Delete plan
  plans = deleteSavedPlan('plan_test_1', store);
  assert.equal(plans.length, 0);
  assert.equal(loadSavedPlans(store).length, 0);
});
