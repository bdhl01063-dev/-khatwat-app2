import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WEB_DIR = path.resolve(__dirname, '..');

class MockClassList {
  constructor(initial = []) {
    this.set = new Set(initial);
  }
  add(...names) {
    names.forEach((n) => this.set.add(n));
  }
  remove(...names) {
    names.forEach((n) => this.set.delete(n));
  }
  toggle(name, force) {
    if (force === undefined) {
      if (this.set.has(name)) this.set.delete(name);
      else this.set.add(name);
    } else if (force) {
      this.set.add(name);
    } else {
      this.set.delete(name);
    }
  }
  contains(name) {
    return this.set.has(name);
  }
}

class MockElement {
  constructor(tagName = 'div', id = '', classes = [], attrs = {}) {
    this.tagName = tagName.toUpperCase();
    this.id = id;
    this.classList = new MockClassList(classes);
    this.dataset = { ...attrs };
    this.style = {};
    this.children = [];
    this.listeners = new Map();
    this._innerHTML = '';
    this.textContent = '';
    this.value = '';
    this.checked = false;
    this.disabled = false;
  }

  set className(str) {
    this.classList = new MockClassList(String(str).split(/\s+/).filter(Boolean));
  }

  get className() {
    return Array.from(this.classList.set).join(' ');
  }

  set innerHTML(html) {
    this._innerHTML = String(html);
    this.children = [];
    if (!html) return;

    // Parse inner interactive elements needed for E2E click tests
    const openIdeaMatch = this._innerHTML.match(/data-open-idea="([^"]+)"/);
    if (openIdeaMatch) {
      this.children.push(
        new MockElement('button', '', ['btn'], { openIdea: openIdeaMatch[1] })
      );
    }

    if (this._innerHTML.includes('class="step-checkbox"')) {
      const cb = new MockElement('input', '', ['step-checkbox']);
      cb.checked = this._innerHTML.includes('checked');
      this.children.push(cb);
    }

    const openSavedMatch = this._innerHTML.match(/data-open-saved="([^"]+)"/);
    if (openSavedMatch) {
      this.children.push(
        new MockElement('button', '', ['btn'], { openSaved: openSavedMatch[1] })
      );
    }

    const delSavedMatch = this._innerHTML.match(/data-delete-saved="([^"]+)"/);
    if (delSavedMatch) {
      this.children.push(
        new MockElement('button', '', ['btn'], { deleteSaved: delSavedMatch[1] })
      );
    }

    if (this._innerHTML.includes('id="btn-empty-saved-start"')) {
      this.children.push(new MockElement('button', 'btn-empty-saved-start', ['btn']));
    }
  }

  get innerHTML() {
    return this._innerHTML;
  }

  appendChild(child) {
    this.children.push(child);
    return child;
  }

  addEventListener(type, fn) {
    if (!this.listeners.has(type)) this.listeners.set(type, []);
    this.listeners.get(type).push(fn);
  }

  dispatchEvent(event) {
    const handlers = this.listeners.get(event.type) || [];
    for (const fn of handlers) {
      fn(event);
    }
  }

  click() {
    this.dispatchEvent({ type: 'click', target: this, preventDefault: () => {} });
  }

  querySelector(selector) {
    if (selector.startsWith('.')) {
      const cls = selector.slice(1);
      return this.children.find((c) => c.classList.contains(cls)) || null;
    }
    if (selector === '[data-open-idea]') {
      return this.children.find((c) => c.dataset.openIdea) || null;
    }
    if (selector === '[data-open-saved]') {
      return this.children.find((c) => c.dataset.openSaved) || null;
    }
    if (selector === '[data-delete-saved]') {
      return this.children.find((c) => c.dataset.deleteSaved) || null;
    }
    return null;
  }
}

function setupMockDom() {
  const html = fs.readFileSync(path.join(WEB_DIR, 'index.html'), 'utf8');
  const byId = new Map();
  const tabBtns = [];
  const quickChips = [];

  // Register every id="..." present in index.html
  const idRegex = /<([a-z0-9]+)([^>]*?)id="([^"]+)"([^>]*)>/gi;
  let m;
  while ((m = idRegex.exec(html)) !== null) {
    const tag = m[1];
    const attrs = `${m[2]} ${m[4]}`;
    const id = m[3];
    const classMatch = attrs.match(/class="([^"]*)"/);
    const classes = classMatch ? classMatch[1].split(/\s+/).filter(Boolean) : [];
    const dataAttrs = {};
    const dataTab = attrs.match(/data-tab="([^"]+)"/);
    if (dataTab) dataAttrs.tab = dataTab[1];

    const el = new MockElement(tag, id, classes, dataAttrs);
    byId.set(id, el);
    if (classes.includes('tab-btn')) tabBtns.push(el);
  }

  // Extract quick-chips inside modal-revise
  const quickChipsRegex = /<button class="chip-btn"[^>]*data-note="([^"]+)"[^>]*>([^<]+)<\/button>/g;
  while ((m = quickChipsRegex.exec(html)) !== null) {
    const chip = new MockElement('button', '', ['chip-btn'], { note: m[1] });
    chip.textContent = m[2];
    quickChips.push(chip);
  }

  const store = new Map();
  const mockLocalStorage = {
    getItem: (k) => (store.has(k) ? store.get(k) : null),
    setItem: (k, v) => store.set(k, String(v)),
    removeItem: (k) => store.delete(k)
  };

  globalThis.window = {
    __KHATWAT_TEST_MODE__: true,
    localStorage: mockLocalStorage,
    scrollTo: () => {},
    print: () => {
      globalThis.__printed = true;
    },
    addEventListener: () => {}
  };
  Object.defineProperty(globalThis, 'navigator', {
    value: { onLine: true },
    configurable: true
  });
  globalThis.document = {
    getElementById: (id) => {
      if (byId.has(id)) return byId.get(id);
      for (const el of byId.values()) {
        for (const ch of el.children) {
          if (ch.id === id) return ch;
        }
      }
      return null;
    },
    createElement: (tag) => new MockElement(tag),
    querySelectorAll: (selector) => {
      if (selector === '.tab-btn') return tabBtns;
      if (selector === '#revise-quick-chips .chip-btn') return quickChips;
      return [];
    }
  };

  return { byId, quickChips, mockLocalStorage };
}

test('End-to-end UI flow tests all buttons, 4-step wizard, detail tabs, step checkboxes, revise modal, and localStorage', async () => {
  const { byId, quickChips, mockLocalStorage } = setupMockDom();
  const { initKhatwatApp } = await import('../app.js');

  const app = initKhatwatApp();
  assert.equal(app.state.currentView, 'landing');
  assert.equal(byId.get('saved-count-badge').textContent, '0');

  // 1. Click Start Wizard
  byId.get('btn-start-wizard').click();
  assert.equal(app.state.currentView, 'wizard');
  assert.equal(app.state.wizardStep, 1);

  // 2. Try Next without selecting skills -> triggers validation error
  byId.get('btn-wizard-next').click();
  assert.equal(app.state.wizardStep, 1);
  assert.equal(byId.get('wizard-error-box').classList.contains('hidden'), false);

  // 3. Select first skill chip + add custom skill -> Step 2
  byId.get('skills-chips').children[0].click();
  byId.get('input-custom-skill').value = 'كتابة عروض';
  byId.get('btn-add-skill').click();
  assert.equal(app.state.profile.customSkillsList.includes('كتابة عروض'), true);

  byId.get('btn-wizard-next').click();
  assert.equal(app.state.wizardStep, 2);

  // 4. Select interest -> Step 3
  byId.get('interests-chips').children[0].click();
  byId.get('btn-wizard-next').click();
  assert.equal(app.state.wizardStep, 3);

  // 5. Enter custom YER budget -> Step 4
  byId.get('input-custom-budget').value = '20000';
  byId.get('input-custom-budget').dispatchEvent({ type: 'input', target: byId.get('input-custom-budget') });
  byId.get('btn-wizard-next').click();
  assert.equal(app.state.wizardStep, 4);

  // 6. Submit questionnaire -> generates 3 ideas and saves to localStorage
  await byId.get('btn-wizard-submit').click();
  assert.equal(app.state.currentView, 'results');
  assert.equal(byId.get('ideas-list').children.length, 3);
  assert.equal(byId.get('saved-count-badge').textContent, '1');

  // 7. Open first idea detail view
  const firstIdeaCard = byId.get('ideas-list').children[0];
  firstIdeaCard.querySelector('[data-open-idea]').click();
  assert.equal(app.state.currentView, 'detail');

  // 8. Toggle first execution step checkbox & verify persistence
  const firstStepLabel = byId.get('detail-steps-list').children[0];
  const cb = firstStepLabel.querySelector('.step-checkbox');
  cb.checked = true;
  cb.dispatchEvent({ type: 'change', target: cb });
  assert.ok(byId.get('detail-steps-progress-label').textContent.startsWith('1/'));

  const persisted = JSON.parse(mockLocalStorage.getItem('khatwat_saved_plans_v1'));
  assert.equal(persisted[0].ideas[0].steps[0].completed, true);

  // 9. Switch Detail tabs (financials & marketing) & test print button
  byId.get('tab-btn-financials').click();
  assert.equal(byId.get('detail-tab-financials').classList.contains('hidden'), false);
  byId.get('tab-btn-marketing').click();
  assert.equal(byId.get('detail-tab-marketing').classList.contains('hidden'), false);
  byId.get('btn-print-plan').click();
  assert.equal(globalThis.__printed, true);

  // 10. Open Revise Plan modal, pick a quick chip, and apply
  byId.get('btn-detail-revise').click();
  assert.equal(byId.get('modal-revise').classList.contains('hidden'), false);
  quickChips[1].click();
  assert.ok(byId.get('input-revise-note').value.includes('عن بُعد'));
  await byId.get('btn-revise-apply').click();
  assert.equal(app.state.currentView, 'results');
  assert.equal(byId.get('saved-count-badge').textContent, '2');

  // 11. Open Saved Plans view and delete one plan
  byId.get('btn-nav-saved').click();
  assert.equal(app.state.currentView, 'saved');
  assert.equal(byId.get('saved-plans-list').children.length, 2);
  byId.get('saved-plans-list').children[0].querySelector('[data-delete-saved]').click();
  assert.equal(byId.get('saved-plans-list').children.length, 1);
  assert.equal(byId.get('saved-count-badge').textContent, '1');

  // 12. Test PWA install help modal open & close
  byId.get('btn-brand-home').click();
  assert.equal(app.state.currentView, 'landing');
  byId.get('btn-install-pwa').click();
  assert.equal(byId.get('modal-install-help').classList.contains('hidden'), false);
  byId.get('btn-install-help-ok').click();
  assert.equal(byId.get('modal-install-help').classList.contains('hidden'), true);
});
