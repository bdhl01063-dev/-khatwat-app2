package com.example

import android.content.Context
import androidx.compose.ui.test.assertIsDisplayed
import androidx.compose.ui.test.junit4.createEmptyComposeRule
import androidx.compose.ui.test.onAllNodesWithContentDescription
import androidx.compose.ui.test.onAllNodesWithText
import androidx.compose.ui.test.onNodeWithTag
import androidx.compose.ui.test.onNodeWithText
import androidx.compose.ui.test.performClick
import androidx.compose.ui.test.performScrollTo
import androidx.compose.ui.test.performTextInput
import androidx.test.core.app.ActivityScenario
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Rule
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34], qualifiers = "w412dp-h915dp-xhdpi")
class ExampleRobolectricTest {

    @get:Rule
    val composeRule = createEmptyComposeRule()

    @Test
    fun `full end to end khatwat flow tests all buttons wizard 3 ideas details revise and persistence after closing and reopening app`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        assertEquals("خطوتك", context.getString(R.string.app_name))
        // Start with clean local DB for deterministic assertions
        context.deleteDatabase("khatwat_local.db")

        ActivityScenario.launch(MainActivity::class.java).use { scenario ->
            composeRule.waitForIdle()

            // 1. Landing screen & TopBar elements
            composeRule.onNodeWithTag("brand_home_button").assertIsDisplayed()
            composeRule.onNodeWithTag("topbar_saved_button").assertIsDisplayed()
            composeRule.onNodeWithTag("start_wizard_button").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithTag("open_saved_button").performScrollTo().assertIsDisplayed()

            // 2. Open Saved screen while empty, then return via empty-state CTA to Wizard
            composeRule.onNodeWithTag("open_saved_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithText("لا توجد خطط محفوظة بعد").assertIsDisplayed()
            composeRule.onNodeWithTag("empty_saved_start_button").performScrollTo().performClick()
            composeRule.waitForIdle()

            // 3. Step 1: Validation error when empty -> select skill + custom Arabic skill + experience
            composeRule.onNodeWithTag("wizard_next_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("wizard_error_banner").performScrollTo().assertIsDisplayed()

            composeRule.onNodeWithTag("skill_chip_writing").performScrollTo().performClick()
            composeRule.onNodeWithTag("custom_skill_input").performScrollTo().performTextInput("إدارة متاجر")
            composeRule.onNodeWithTag("add_custom_skill_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("custom_skill_chip_0").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithTag("experience_option_intermediate").performScrollTo().performClick()

            composeRule.onNodeWithTag("wizard_next_button").performScrollTo().performClick()
            composeRule.waitForIdle()

            // 4. Step 2: Validation error -> select interest + passion note + test Back & Next preservation
            composeRule.onNodeWithTag("wizard_next_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("wizard_error_banner").performScrollTo().assertIsDisplayed()

            composeRule.onNodeWithTag("interest_chip_digital_services").performScrollTo().performClick()
            composeRule.onNodeWithTag("passion_note_input").performScrollTo().performTextInput("أحب التسويق عبر واتساب")

            // Test Previous preserves state and returns cleanly
            composeRule.onNodeWithTag("wizard_prev_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("custom_skill_chip_0").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithTag("wizard_next_button").performScrollTo().performClick()
            composeRule.waitForIdle()

            // Advance to Step 3
            composeRule.onNodeWithTag("wizard_next_button").performScrollTo().performClick()
            composeRule.waitForIdle()

            // 5. Step 3: Enter Arabic-Indic YER budget & weekly hours
            composeRule.onNodeWithTag("custom_budget_input").performScrollTo().performTextInput("٢٥٠٠٠")
            composeRule.onNodeWithTag("hours_option_15_25").performScrollTo().performClick()
            composeRule.onNodeWithTag("wizard_next_button").performScrollTo().performClick()
            composeRule.waitForIdle()

            // 6. Step 4: Work mode, city, optional Gemini accordion (non-paid), submit
            composeRule.onNodeWithTag("location_option_remote").performScrollTo().performClick()
            composeRule.onNodeWithTag("city_input").performScrollTo().performTextInput("صنعاء")
            composeRule.onNodeWithTag("optional_gemini_toggle").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithText("التطبيق يعمل محلياً ومجاناً 100% دون إنترنت. هذا الخيار إضافي فقط إن توفر لديك مفتاح Google AI Studio مجاني.")
                .performScrollTo()
                .assertIsDisplayed()

            composeRule.onNodeWithTag("wizard_submit_button").performScrollTo().performClick()

            // Wait until Results finish loading from analyzer & Room save
            composeRule.waitUntil(timeoutMillis = 5_000) {
                composeRule.onAllNodesWithText("أفضل 3 أفكار مشاريع تناسبك").fetchSemanticsNodes().isNotEmpty()
            }
            composeRule.waitForIdle()

            // 7. Verify 3 tailored ideas + cost/revenue YER estimates + disclaimer + action buttons
            composeRule.onNodeWithTag("revise_plan_button").assertIsDisplayed()
            composeRule.onNodeWithTag("save_plan_button").assertIsDisplayed()
            composeRule.onNodeWithTag("new_analysis_button").assertIsDisplayed()
            composeRule.onNodeWithTag("idea_card_1").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithTag("idea_card_2").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithTag("idea_card_3").performScrollTo().assertIsDisplayed()

            // Save explicitly
            composeRule.onNodeWithTag("save_plan_button").performScrollTo().performClick()
            composeRule.waitForIdle()

            // 8. Open Idea #1 detail screen -> verify execution steps, costs/profits, and marketing tabs
            composeRule.onNodeWithTag("open_idea_button_1").performScrollTo().performClick()
            composeRule.waitForIdle()

            // Toggle Step 1 and verify progress becomes 1/...
            composeRule.onNodeWithTag("step_item_1").performScrollTo().performClick()
            composeRule.waitUntil(timeoutMillis = 5_000) {
                composeRule.onAllNodesWithText("1/", substring = true).fetchSemanticsNodes().isNotEmpty()
            }
            composeRule.onNodeWithTag("steps_progress_text").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithText("1/", substring = true).performScrollTo().assertIsDisplayed()

            // Switch to Financials tab (costs & estimated revenue in YER + disclaimer)
            composeRule.onNodeWithTag("tab_financials").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithText("التقديرات المالية بالريال اليمني (YER)").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithText("رأس المال التأسيسي التقديري").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithText("العائد الشهري التقديري (غير مضمون)").performScrollTo().assertIsDisplayed()

            // Switch to Marketing tab
            composeRule.onNodeWithTag("tab_marketing").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithText("خطة التسويق والانطلاق العملي").performScrollTo().assertIsDisplayed()
            composeRule.onNodeWithText("الجمهور المستهدف").performScrollTo().assertIsDisplayed()

            // Go back to Results via Detail back button
            composeRule.onNodeWithTag("detail_back_button").performScrollTo().performClick()
            composeRule.waitForIdle()

            // 9. Test Revise Plan modal sheet
            composeRule.onNodeWithTag("revise_plan_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("revise_quick_chip_2").performClick()
            composeRule.onNodeWithTag("revise_apply_button").performClick()
            composeRule.waitUntil(timeoutMillis = 5_000) {
                composeRule.onAllNodesWithText("أفضل 3 أفكار مشاريع تناسبك").fetchSemanticsNodes().isNotEmpty()
            }
            composeRule.waitForIdle()

            // Open Revise sheet again and test "Edit Answers" button
            composeRule.onNodeWithTag("revise_plan_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("revise_edit_answers_button").performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("custom_skill_chip_0").performScrollTo().assertIsDisplayed()

            // Test rotation / configuration recreate preserves wizard answers
            scenario.recreate()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("custom_skill_chip_0").performScrollTo().assertIsDisplayed()
        }

        // 10. Real App Close & Reopen: launch a brand new MainActivity instance (fresh ViewModelStore)
        ActivityScenario.launch(MainActivity::class.java).use {
            composeRule.waitForIdle()

            // Opens on Khatwat Landing Screen with persisted saved count from Room DB
            composeRule.onNodeWithTag("start_wizard_button").performScrollTo().assertIsDisplayed()
            composeRule.waitUntil(timeoutMillis = 5_000) {
                composeRule.onAllNodesWithText("خططي المحفوظة (2)").fetchSemanticsNodes().isNotEmpty()
            }

            // Open Saved Plans via TopBar button
            composeRule.onNodeWithTag("topbar_saved_button").performClick()
            composeRule.waitForIdle()

            composeRule.waitUntil(timeoutMillis = 5_000) {
                composeRule.onAllNodesWithText("فتح الخطة").fetchSemanticsNodes().size == 2
            }

            // Verify the original plan shows 1 completed step in its summary, reopen it, and verify step 1 is still checked
            val planCardsWithProgress = composeRule.onAllNodesWithText("1 من ", substring = true)
            assertTrue(planCardsWithProgress.fetchSemanticsNodes().isNotEmpty())

            composeRule.onAllNodesWithText("فتح الخطة")[1].performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("open_idea_button_1").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithText("1/", substring = true).performScrollTo().assertIsDisplayed()

            // Navigate to Saved screen, delete 1 plan, and verify count drops to 1; also test "خطة جديدة" & "brand_home_button"
            composeRule.onNodeWithTag("topbar_saved_button").performClick()
            composeRule.waitForIdle()
            composeRule.onAllNodesWithContentDescription("حذف الخطة")[0].performScrollTo().performClick()
            composeRule.waitUntil(timeoutMillis = 5_000) {
                composeRule.onAllNodesWithText("فتح الخطة").fetchSemanticsNodes().size == 1
            }

            composeRule.onNodeWithTag("saved_new_plan_button").performScrollTo().performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("wizard_next_button").performScrollTo().assertIsDisplayed()

            composeRule.onNodeWithTag("brand_home_button").performClick()
            composeRule.waitForIdle()
            composeRule.onNodeWithTag("start_wizard_button").performScrollTo().assertIsDisplayed()
        }
    }
}
