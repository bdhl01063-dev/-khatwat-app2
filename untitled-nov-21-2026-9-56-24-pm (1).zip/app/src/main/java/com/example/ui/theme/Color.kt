package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val Navy950 = Color(0xFF091426)
val Navy900 = Color(0xFF0F1E36)
val Navy800 = Color(0xFF1B365D)
val Navy700 = Color(0xFF264778)
val Navy100 = Color(0xFFE8EEF7)
val Navy50 = Color(0xFFF2F5FA)

val Orange600 = Color(0xFFEA580C)
val Orange500 = Color(0xFFF97316)
val Orange400 = Color(0xFFFB923C)
val Orange100 = Color(0xFFFFF7ED)
val Orange200 = Color(0xFFFED7AA)

val PureWhite = Color(0xFFFFFFFF)
val CanvasOffWhite = Color(0xFFF6F8FB)
val BorderSubtle = Color(0xFFE2E8F0)
val TextSecondary = Color(0xFF475569)
val TextMuted = Color(0xFF64748B)

val SuccessGreen = Color(0xFF15803D)
val SuccessGreenBg = Color(0xFFDCFCE7)
val WarningAmberText = Color(0xFF92400E)
val WarningAmberBg = Color(0xFFFEF3C7)
val WarningAmberBorder = Color(0xFFFCD34D)
val ErrorRed = Color(0xFFB91C1C)
val ErrorRedBg = Color(0xFFFEE2E2)
