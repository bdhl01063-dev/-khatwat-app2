package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

private val KhatwatLightColorScheme = lightColorScheme(
    primary = Orange500,
    onPrimary = PureWhite,
    primaryContainer = Orange100,
    onPrimaryContainer = Orange600,
    secondary = Navy900,
    onSecondary = PureWhite,
    secondaryContainer = Navy100,
    onSecondaryContainer = Navy900,
    tertiary = Navy800,
    onTertiary = PureWhite,
    background = CanvasOffWhite,
    onBackground = Navy900,
    surface = PureWhite,
    onSurface = Navy900,
    surfaceVariant = Navy50,
    onSurfaceVariant = TextSecondary,
    outline = BorderSubtle,
    error = ErrorRed,
    onError = PureWhite,
    errorContainer = ErrorRedBg,
    onErrorContainer = ErrorRed
)

private val KhatwatShapes = Shapes(
    small = RoundedCornerShape(10.dp),
    medium = RoundedCornerShape(16.dp),
    large = RoundedCornerShape(22.dp)
)

@Composable
fun KhatwatTheme(
    content: @Composable () -> Unit
) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = KhatwatLightColorScheme,
            typography = KhatwatTypography,
            shapes = KhatwatShapes,
            content = content
        )
    }
}
