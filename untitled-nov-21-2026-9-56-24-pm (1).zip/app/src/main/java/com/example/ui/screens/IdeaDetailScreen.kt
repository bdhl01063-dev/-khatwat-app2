package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material3.Checkbox
import androidx.compose.material3.CheckboxDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import com.example.domain.BusinessIdea
import com.example.domain.ExecutionStep
import com.example.ui.DetailTab
import com.example.ui.components.AlertBanner
import com.example.ui.components.AlertBannerType
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CanvasOffWhite
import com.example.ui.theme.Navy100
import com.example.ui.theme.Navy50
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.Orange100
import com.example.ui.theme.Orange200
import com.example.ui.theme.Orange500
import com.example.ui.theme.Orange600
import com.example.ui.theme.PureWhite
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.SuccessGreenBg
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun IdeaDetailScreen(
    idea: BusinessIdea,
    selectedTab: DetailTab,
    onSelectTab: (DetailTab) -> Unit,
    onToggleStep: (String) -> Unit,
    onOpenRevise: () -> Unit,
    onBack: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBack() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header & Tabs Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = PureWhite,
                border = BorderStroke(1.dp, BorderSubtle),
                shadowElevation = 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = onBack,
                            modifier = Modifier.testTag("detail_back_button"),
                            border = BorderStroke(1.dp, BorderSubtle),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("العودة للأفكار")
                        }

                        OutlinedButton(
                            onClick = onOpenRevise,
                            modifier = Modifier.testTag("detail_revise_button"),
                            border = BorderStroke(1.dp, Orange200),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Rounded.EditNote, contentDescription = null, tint = Orange600, modifier = Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp))
                            Text("تعديل الخطة", color = Orange600)
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(999.dp),
                        color = Orange100,
                        border = BorderStroke(1.dp, Orange200)
                    ) {
                        Text(
                            text = idea.workModeLabel,
                            style = MaterialTheme.typography.labelSmall,
                            color = Orange600,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }

                    Text(text = idea.title, style = MaterialTheme.typography.headlineMedium, color = Navy900)
                    Text(text = idea.summary, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(14.dp))
                            .background(Navy100)
                            .padding(4.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        DetailTabButton(
                            label = "خطة التنفيذ",
                            selected = selectedTab == DetailTab.STEPS,
                            onClick = { onSelectTab(DetailTab.STEPS) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tab_steps")
                        )
                        DetailTabButton(
                            label = "التكاليف والعوائد",
                            selected = selectedTab == DetailTab.FINANCIALS,
                            onClick = { onSelectTab(DetailTab.FINANCIALS) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tab_financials")
                        )
                        DetailTabButton(
                            label = "خطة التسويق",
                            selected = selectedTab == DetailTab.MARKETING,
                            onClick = { onSelectTab(DetailTab.MARKETING) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("tab_marketing")
                        )
                    }
                }
            }

            when (selectedTab) {
                DetailTab.STEPS -> StepsTabCard(idea = idea, onToggleStep = onToggleStep)
                DetailTab.FINANCIALS -> FinancialsTabCard(idea = idea)
                DetailTab.MARKETING -> MarketingTabCard(idea = idea)
            }
        }
    }
}

@Composable
private fun DetailTabButton(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (selected) PureWhite else Navy100,
        shadowElevation = if (selected) 2.dp else 0.dp,
        modifier = modifier
            .clip(RoundedCornerShape(10.dp))
            .clickable(onClick = onClick)
    ) {
        Box(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                color = if (selected) Navy900 else Navy800,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium
            )
        }
    }
}

@Composable
private fun StepsTabCard(
    idea: BusinessIdea,
    onToggleStep: (String) -> Unit
) {
    val pct = idea.progressPercent()
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = PureWhite,
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("تقدم التنفيذ الفعلي", style = MaterialTheme.typography.titleMedium, color = Navy900)
                Text(
                    text = "${idea.completedStepsCount()}/${idea.steps.size} ($pct%)",
                    style = MaterialTheme.typography.labelLarge,
                    color = Orange600,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.testTag("steps_progress_text")
                )
            }

            LinearProgressIndicator(
                progress = { pct / 100f },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(10.dp)
                    .clip(RoundedCornerShape(999.dp)),
                color = Orange500,
                trackColor = Navy100
            )

            idea.steps.forEachIndexed { index, step ->
                StepChecklistItem(
                    index = index + 1,
                    step = step,
                    onToggle = { onToggleStep(step.id) }
                )
            }
        }
    }
}

@Composable
private fun StepChecklistItem(
    index: Int,
    step: ExecutionStep,
    onToggle: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(14.dp),
        color = if (step.completed) SuccessGreenBg.copy(alpha = 0.55f) else CanvasOffWhite,
        border = BorderStroke(1.5.dp, if (step.completed) SuccessGreen.copy(alpha = 0.45f) else BorderSubtle),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onToggle)
            .testTag("step_item_$index")
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Checkbox(
                checked = step.completed,
                onCheckedChange = { onToggle() },
                colors = CheckboxDefaults.colors(checkedColor = Orange500)
            )
            Column(modifier = Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "$index. ${step.title}",
                        style = MaterialTheme.typography.titleMedium,
                        color = if (step.completed) SuccessGreen else Navy900,
                        textDecoration = if (step.completed) TextDecoration.LineThrough else TextDecoration.None,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(Modifier.width(6.dp))
                    Surface(shape = RoundedCornerShape(999.dp), color = Orange100) {
                        Text(
                            text = step.timeframe,
                            style = MaterialTheme.typography.labelSmall,
                            color = Orange600,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                }
                Text(
                    text = step.description,
                    style = MaterialTheme.typography.bodyMedium,
                    color = TextSecondary
                )
            }
        }
    }
}

@Composable
private fun FinancialsTabCard(idea: BusinessIdea) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = PureWhite,
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "التقديرات المالية بالريال اليمني (YER)",
                style = MaterialTheme.typography.titleLarge,
                color = Navy900
            )

            FinancialTile("رأس المال التأسيسي التقديري", idea.financials.startupRangeLabel)
            FinancialTile("العائد الشهري التقديري (غير مضمون)", idea.financials.monthlyRevenue)
            FinancialTile("المصاريف التشغيلية التقديرية", idea.financials.monthlyExpense)
            FinancialTile("فترة الاسترداد التقريبية", idea.financials.breakEven)

            Text(
                text = "تفصيل بنود التأسيس التقديرية",
                style = MaterialTheme.typography.titleMedium,
                color = Navy800
            )

            idea.financials.startupItems.forEach { cost ->
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = CanvasOffWhite,
                    border = BorderStroke(1.dp, BorderSubtle),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = cost.item,
                            style = MaterialTheme.typography.bodyMedium,
                            color = TextSecondary,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(Modifier.width(8.dp))
                        Text(
                            text = cost.range,
                            style = MaterialTheme.typography.labelLarge,
                            color = Navy900,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            AlertBanner(
                text = idea.financials.disclaimer,
                type = AlertBannerType.WARNING
            )
        }
    }
}

@Composable
private fun FinancialTile(label: String, value: String) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = Navy50,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text(text = value, style = MaterialTheme.typography.titleMedium, color = Navy900, fontWeight = FontWeight.Bold)
        }
    }
}

@Composable
private fun MarketingTabCard(idea: BusinessIdea) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = PureWhite,
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "خطة التسويق والانطلاق العملي",
                style = MaterialTheme.typography.titleLarge,
                color = Navy900
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Navy50)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                Text("الجمهور المستهدف", style = MaterialTheme.typography.titleMedium, color = Navy900)
                Text(idea.marketing.targetAudience, style = MaterialTheme.typography.bodyMedium, color = TextSecondary)
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Navy50)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text("أفضل القنوات منخفضة التكلفة", style = MaterialTheme.typography.titleMedium, color = Navy900)
                idea.marketing.channels.forEach { channel ->
                    Text("• $channel", style = MaterialTheme.typography.bodyMedium, color = Navy800)
                }
            }

            AlertBanner(
                text = "خطوة الأسبوع الأول: ${idea.marketing.firstWeekActions}",
                type = AlertBannerType.INFO
            )

            AlertBanner(
                text = "نصيحة التسعير: ${idea.marketing.pricingTip}",
                type = AlertBannerType.SUCCESS
            )
        }
    }
}
