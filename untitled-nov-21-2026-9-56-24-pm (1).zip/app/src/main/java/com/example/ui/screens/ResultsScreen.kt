package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.BookmarkAdded
import androidx.compose.material.icons.rounded.EditNote
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.domain.BusinessIdea
import com.example.domain.BusinessPlanBundle
import com.example.ui.AnalysisUiState
import com.example.ui.components.AlertBanner
import com.example.ui.components.AlertBannerType
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.CanvasOffWhite
import com.example.ui.theme.Navy50
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.Orange100
import com.example.ui.theme.Orange200
import com.example.ui.theme.Orange500
import com.example.ui.theme.Orange600
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextSecondary

@Composable
fun ResultsScreen(
    analysisState: AnalysisUiState,
    onOpenIdea: (String) -> Unit,
    onOpenRevise: () -> Unit,
    onSavePlan: () -> Unit,
    onNewAnalysis: () -> Unit,
    onRetry: () -> Unit,
    onBackHome: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onBackHome() }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            when (analysisState) {
                is AnalysisUiState.Idle,
                is AnalysisUiState.Loading -> {
                    Surface(
                        shape = RoundedCornerShape(18.dp),
                        color = PureWhite,
                        border = BorderStroke(1.dp, BorderSubtle),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(
                            modifier = Modifier.padding(32.dp),
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            CircularProgressIndicator(color = Orange500)
                            Text(
                                text = "جاري تحليل مهاراتك وميزانيتك...",
                                style = MaterialTheme.typography.titleLarge,
                                color = Navy900
                            )
                            Text(
                                text = "نقارن مدخلاتك الآن مع نماذج المشاريع العملية بالريال اليمني دون أي خدمات مدفوعة.",
                                style = MaterialTheme.typography.bodyMedium,
                                color = TextSecondary
                            )
                        }
                    }
                }

                is AnalysisUiState.Error -> {
                    AlertBanner(text = analysisState.message, type = AlertBannerType.ERROR)
                    Button(
                        onClick = onRetry,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = Orange500, contentColor = PureWhite),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Icon(Icons.Rounded.Refresh, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text("إعادة المحاولة", style = MaterialTheme.typography.labelLarge)
                    }
                }

                is AnalysisUiState.Success -> {
                    ResultsContent(
                        bundle = analysisState.bundle,
                        onOpenIdea = onOpenIdea,
                        onOpenRevise = onOpenRevise,
                        onSavePlan = onSavePlan,
                        onNewAnalysis = onNewAnalysis
                    )
                }
            }
        }
    }
}

@Composable
private fun ResultsContent(
    bundle: BusinessPlanBundle,
    onOpenIdea: (String) -> Unit,
    onOpenRevise: () -> Unit,
    onSavePlan: () -> Unit,
    onNewAnalysis: () -> Unit
) {
    // Navy Summary Card
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = Navy900,
        contentColor = PureWhite,
        shadowElevation = 4.dp,
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(
                text = "أفضل 3 أفكار مشاريع تناسبك",
                style = MaterialTheme.typography.headlineMedium,
                color = PureWhite
            )
            Text(
                text = "الميزانية: ${bundle.profile.getBudgetLabel()} · العمل: ${bundle.profile.getLocationLabel()}" +
                    if (bundle.revisionNote.isNotBlank()) " · التعديل: ${bundle.revisionNote}" else "",
                style = MaterialTheme.typography.bodyMedium,
                color = PureWhite.copy(alpha = 0.85f)
            )
            Surface(
                shape = RoundedCornerShape(999.dp),
                color = PureWhite.copy(alpha = 0.12f)
            ) {
                Text(
                    text = bundle.sourceLabel,
                    style = MaterialTheme.typography.labelSmall,
                    color = Orange100,
                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                )
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Button(
                    onClick = onOpenRevise,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("revise_plan_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = Orange500, contentColor = PureWhite),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.EditNote, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("تعديل الخطة", style = MaterialTheme.typography.labelLarge)
                }

                OutlinedButton(
                    onClick = onSavePlan,
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                        .testTag("save_plan_button"),
                    border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.3f)),
                    colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Rounded.BookmarkAdded, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(Modifier.width(6.dp))
                    Text("حفظ في خططي", style = MaterialTheme.typography.labelLarge)
                }
            }

            OutlinedButton(
                onClick = onNewAnalysis,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(46.dp)
                    .testTag("new_analysis_button"),
                border = BorderStroke(1.dp, PureWhite.copy(alpha = 0.25f)),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = PureWhite),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("استبيان جديد", style = MaterialTheme.typography.labelLarge)
            }
        }
    }

    if (bundle.fallbackNotice.isNotBlank()) {
        AlertBanner(text = bundle.fallbackNotice, type = AlertBannerType.INFO)
    }

    AlertBanner(text = bundle.disclaimer, type = AlertBannerType.WARNING)

    bundle.ideas.forEach { idea ->
        IdeaSummaryCard(
            idea = idea,
            onOpenIdea = { onOpenIdea(idea.id) }
        )
    }
}

@Composable
private fun IdeaSummaryCard(
    idea: BusinessIdea,
    onOpenIdea: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = PureWhite,
        border = BorderStroke(1.5.dp, BorderSubtle),
        shadowElevation = 2.dp,
        modifier = Modifier
            .fillMaxWidth()
            .testTag("idea_card_${idea.rank}")
    ) {
        Column(
            modifier = Modifier.padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Navy900
                ) {
                    Text(
                        text = "الفكرة #${idea.rank}",
                        style = MaterialTheme.typography.labelSmall,
                        color = PureWhite,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 5.dp)
                    )
                }
                Surface(
                    shape = RoundedCornerShape(999.dp),
                    color = Orange100,
                    border = BorderStroke(1.dp, Orange200)
                ) {
                    Text(
                        text = idea.workModeLabel,
                        style = MaterialTheme.typography.labelSmall,
                        color = Orange600,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                    )
                }
            }

            Text(
                text = idea.title,
                style = MaterialTheme.typography.titleLarge,
                color = Navy900
            )

            Text(
                text = idea.summary,
                style = MaterialTheme.typography.bodyMedium,
                color = TextSecondary
            )

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(12.dp))
                    .background(Navy50)
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Text(
                    text = "لماذا تناسبك هذه الفكرة؟",
                    style = MaterialTheme.typography.titleMedium,
                    color = Navy900,
                    fontWeight = FontWeight.Bold
                )
                idea.reasons.forEach { reason ->
                    Text(
                        text = "• $reason",
                        style = MaterialTheme.typography.bodyMedium,
                        color = Navy800
                    )
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                MetricBox(
                    label = "التكلفة التأسيسية التقديرية",
                    value = idea.financials.startupRangeLabel,
                    modifier = Modifier.weight(1f)
                )
                MetricBox(
                    label = "العائد الشهري التقديري (غير مضمون)",
                    value = idea.financials.monthlyRevenue,
                    modifier = Modifier.weight(1f)
                )
            }

            Button(
                onClick = onOpenIdea,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
                    .testTag("open_idea_button_${idea.rank}"),
                colors = ButtonDefaults.buttonColors(containerColor = Orange500, contentColor = PureWhite),
                shape = RoundedCornerShape(14.dp)
            ) {
                Text(
                    text = "عرض خطة التنفيذ والتسويق (${idea.completedStepsCount()}/${idea.steps.size} خطوات)",
                    style = MaterialTheme.typography.labelLarge
                )
                Spacer(Modifier.width(6.dp))
                Icon(Icons.AutoMirrored.Rounded.ArrowForward, contentDescription = null, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
private fun MetricBox(
    label: String,
    value: String,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = CanvasOffWhite,
        border = BorderStroke(1.dp, BorderSubtle),
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = TextMuted)
            Text(text = value, style = MaterialTheme.typography.bodyMedium, color = Navy900, fontWeight = FontWeight.Bold)
        }
    }
}
