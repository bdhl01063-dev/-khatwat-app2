package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import com.example.domain.KhatwatCatalog
import com.example.domain.QuestionnaireProfile
import com.example.ui.components.AlertBanner
import com.example.ui.components.AlertBannerType
import com.example.ui.components.OptionSelectCard
import com.example.ui.components.SelectablePillChip
import com.example.ui.theme.BorderSubtle
import com.example.ui.theme.Navy100
import com.example.ui.theme.Navy800
import com.example.ui.theme.Navy900
import com.example.ui.theme.Orange500
import com.example.ui.theme.PureWhite
import com.example.ui.theme.TextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QuestionnaireWizardScreen(
    step: Int,
    profile: QuestionnaireProfile,
    errorMessage: String?,
    useOptionalGemini: Boolean,
    optionalGeminiKey: String,
    onToggleSkill: (String) -> Unit,
    onAddCustomSkill: (String) -> Unit,
    onRemoveCustomSkill: (String) -> Unit,
    onSelectExperience: (String) -> Unit,
    onToggleInterest: (String) -> Unit,
    onUpdatePassionNote: (String) -> Unit,
    onSelectBudget: (String) -> Unit,
    onUpdateCustomBudget: (String) -> Unit,
    onSelectHours: (String) -> Unit,
    onSelectLocation: (String) -> Unit,
    onToggleTool: (String) -> Unit,
    onUpdateCity: (String) -> Unit,
    onToggleOptionalGemini: (Boolean, String) -> Unit,
    onPrevious: () -> Unit,
    onNext: () -> Unit,
    onSubmit: () -> Unit,
    modifier: Modifier = Modifier
) {
    BackHandler { onPrevious() }

    val stepTitle = when (step) {
        1 -> "الخطوة 1 من 4: المهارات والخبرات"
        2 -> "الخطوة 2 من 4: الاهتمامات والمجالات"
        3 -> "الخطوة 3 من 4: الميزانية (YER) والوقت"
        else -> "الخطوة 4 من 4: بيئة العمل والأدوات"
    }
    val progress = step / 4f
    val scrollState = rememberScrollState()
    LaunchedEffect(step) {
        scrollState.scrollTo(0)
    }

    Column(
        modifier = modifier
            .fillMaxWidth()
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 18.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Surface(
            shape = RoundedCornerShape(18.dp),
            color = PureWhite,
            border = BorderStroke(1.dp, BorderSubtle),
            shadowElevation = 2.dp,
            modifier = Modifier
                .fillMaxWidth()
                .widthIn(max = 640.dp)
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = stepTitle,
                        style = MaterialTheme.typography.titleMedium,
                        color = Navy800,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "${step * 25}%",
                        style = MaterialTheme.typography.labelLarge,
                        color = Orange500,
                        fontWeight = FontWeight.Bold
                    )
                }

                LinearProgressIndicator(
                    progress = { progress },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(10.dp)
                        .clip(RoundedCornerShape(999.dp)),
                    color = Orange500,
                    trackColor = Navy100
                )

                AnimatedContent(targetState = step, label = "wizard_step_transition") { currentStep ->
                    when (currentStep) {
                        1 -> StepOneSkills(
                            profile = profile,
                            onToggleSkill = onToggleSkill,
                            onAddCustomSkill = onAddCustomSkill,
                            onRemoveCustomSkill = onRemoveCustomSkill,
                            onSelectExperience = onSelectExperience
                        )
                        2 -> StepTwoInterests(
                            profile = profile,
                            onToggleInterest = onToggleInterest,
                            onUpdatePassionNote = onUpdatePassionNote
                        )
                        3 -> StepThreeBudgetAndTime(
                            profile = profile,
                            onSelectBudget = onSelectBudget,
                            onUpdateCustomBudget = onUpdateCustomBudget,
                            onSelectHours = onSelectHours
                        )
                        else -> StepFourEnvironment(
                            profile = profile,
                            useOptionalGemini = useOptionalGemini,
                            optionalGeminiKey = optionalGeminiKey,
                            onSelectLocation = onSelectLocation,
                            onToggleTool = onToggleTool,
                            onUpdateCity = onUpdateCity,
                            onToggleOptionalGemini = onToggleOptionalGemini
                        )
                    }
                }

                if (!errorMessage.isNullOrBlank()) {
                    AlertBanner(
                        text = errorMessage,
                        type = AlertBannerType.ERROR,
                        modifier = Modifier.testTag("wizard_error_banner")
                    )
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onPrevious,
                        modifier = Modifier
                            .weight(1f)
                            .height(50.dp)
                            .testTag("wizard_prev_button"),
                        border = BorderStroke(1.5.dp, BorderSubtle),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Text(
                            text = if (step == 1) "الرئيسية" else "السابق",
                            style = MaterialTheme.typography.labelLarge,
                            color = Navy900
                        )
                    }

                    if (step < 4) {
                        Button(
                            onClick = onNext,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("wizard_next_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Orange500,
                                contentColor = PureWhite
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("التالي", style = MaterialTheme.typography.labelLarge)
                        }
                    } else {
                        Button(
                            onClick = onSubmit,
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp)
                                .testTag("wizard_submit_button"),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Orange500,
                                contentColor = PureWhite
                            ),
                            shape = RoundedCornerShape(14.dp)
                        ) {
                            Text("عرض 3 أفكار مناسبة لي", style = MaterialTheme.typography.labelLarge)
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StepOneSkills(
    profile: QuestionnaireProfile,
    onToggleSkill: (String) -> Unit,
    onAddCustomSkill: (String) -> Unit,
    onRemoveCustomSkill: (String) -> Unit,
    onSelectExperience: (String) -> Unit
) {
    var customInput by remember { mutableStateOf("") }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ما هي مهاراتك أو نقاط قوتك الحالية؟", style = MaterialTheme.typography.titleLarge, color = Navy900)
        Text("اختر مهارة واحدة أو أكثر لتخصيص أفكار المشاريع:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KhatwatCatalog.skillOptions.forEach { opt ->
                SelectablePillChip(
                    label = opt.label,
                    selected = opt.id in profile.skills,
                    onClick = { onToggleSkill(opt.id) },
                    modifier = Modifier.testTag("skill_chip_${opt.id}")
                )
            }
        }

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedTextField(
                value = customInput,
                onValueChange = { customInput = it },
                modifier = Modifier
                    .weight(1f)
                    .testTag("custom_skill_input"),
                label = { Text("مهارة إضافية (اختياري)") },
                placeholder = { Text("مثال: طاقة شمسية، تطريز...") },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )
            Button(
                onClick = {
                    if (customInput.isNotBlank()) {
                        onAddCustomSkill(customInput)
                        customInput = ""
                    }
                },
                modifier = Modifier
                    .height(54.dp)
                    .testTag("add_custom_skill_button"),
                colors = ButtonDefaults.buttonColors(containerColor = Navy900, contentColor = PureWhite),
                shape = RoundedCornerShape(12.dp)
            ) {
                Text("إضافة")
            }
        }

        if (profile.customSkills.isNotEmpty()) {
            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                profile.customSkills.forEachIndexed { idx, custom ->
                    SelectablePillChip(
                        label = "$custom ×",
                        selected = true,
                        accentOrange = true,
                        onClick = { onRemoveCustomSkill(custom) },
                        modifier = Modifier.testTag("custom_skill_chip_$idx")
                    )
                }
            }
        }

        Text("مستوى خبرتك في هذه المهارات", style = MaterialTheme.typography.titleMedium, color = Navy900)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            KhatwatCatalog.experienceOptions.forEach { exp ->
                OptionSelectCard(
                    title = exp.label,
                    subtitle = exp.hint,
                    selected = profile.experienceId == exp.id,
                    onClick = { onSelectExperience(exp.id) },
                    modifier = Modifier.testTag("experience_option_${exp.id}")
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StepTwoInterests(
    profile: QuestionnaireProfile,
    onToggleInterest: (String) -> Unit,
    onUpdatePassionNote: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ما المجالات التي تهمك وتستمتع بالعمل فيها؟", style = MaterialTheme.typography.titleLarge, color = Navy900)
        Text("يساعدنا ذلك على اختيار مشاريع تستمر فيها بحماس:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KhatwatCatalog.interestOptions.forEach { opt ->
                SelectablePillChip(
                    label = opt.label,
                    selected = opt.id in profile.interests,
                    onClick = { onToggleInterest(opt.id) },
                    modifier = Modifier.testTag("interest_chip_${opt.id}")
                )
            }
        }

        OutlinedTextField(
            value = profile.passionNote,
            onValueChange = onUpdatePassionNote,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("passion_note_input"),
            label = { Text("نبذة عن اهتمامك أو فكرتك (اختياري)") },
            placeholder = { Text("مثال: أحب التسويق عبر واتساب أو تحضير الحلويات من المنزل...") },
            minLines = 3,
            shape = RoundedCornerShape(12.dp)
        )
    }
}

@Composable
private fun StepThreeBudgetAndTime(
    profile: QuestionnaireProfile,
    onSelectBudget: (String) -> Unit,
    onUpdateCustomBudget: (String) -> Unit,
    onSelectHours: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ما ميزانيتك بالريال اليمني ووقتك المتاح؟", style = MaterialTheme.typography.titleLarge, color = Navy900)
        Text("نلتزم باقتراح أفكار تناسب رأس المال المحدد:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

        Text("رأس المال التأسيسي المتاح (YER)", style = MaterialTheme.typography.titleMedium, color = Navy900)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            KhatwatCatalog.budgetOptions.forEach { opt ->
                val isSelected = profile.budgetId == opt.id && profile.customBudgetYer.isBlank()
                OptionSelectCard(
                    title = opt.label,
                    subtitle = opt.hint,
                    selected = isSelected,
                    onClick = { onSelectBudget(opt.id) },
                    modifier = Modifier.testTag("budget_option_${opt.id}")
                )
            }
        }

        OutlinedTextField(
            value = profile.customBudgetYer,
            onValueChange = onUpdateCustomBudget,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("custom_budget_input"),
            label = { Text("أو أدخل مبلغاً مخصصاً بالريال اليمني (اختياري)") },
            placeholder = { Text("مثال: 35000") },
            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Text("الوقت المتاح أسبوعياً للمشروع", style = MaterialTheme.typography.titleMedium, color = Navy900)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            KhatwatCatalog.hoursOptions.forEach { opt ->
                OptionSelectCard(
                    title = opt.label,
                    subtitle = opt.hint,
                    selected = profile.hoursId == opt.id,
                    onClick = { onSelectHours(opt.id) },
                    modifier = Modifier.testTag("hours_option_${opt.id}")
                )
            }
        }
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun StepFourEnvironment(
    profile: QuestionnaireProfile,
    useOptionalGemini: Boolean,
    optionalGeminiKey: String,
    onSelectLocation: (String) -> Unit,
    onToggleTool: (String) -> Unit,
    onUpdateCity: (String) -> Unit,
    onToggleOptionalGemini: (Boolean, String) -> Unit
) {
    var showOptionalAi by remember { mutableStateOf(false) }

    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("كيف تفضل العمل وما الأدوات المتوفرة؟", style = MaterialTheme.typography.titleLarge, color = Navy900)
        Text("لتفادي اقتراح أفكار تحتاج معدات أو تنقلاً غير متاح:", style = MaterialTheme.typography.bodyMedium, color = TextSecondary)

        Text("تفضيل مكان العمل", style = MaterialTheme.typography.titleMedium, color = Navy900)
        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            KhatwatCatalog.locationOptions.forEach { opt ->
                OptionSelectCard(
                    title = opt.label,
                    subtitle = opt.hint,
                    selected = profile.locationPreference == opt.id,
                    onClick = { onSelectLocation(opt.id) },
                    modifier = Modifier.testTag("location_option_${opt.id}")
                )
            }
        }

        Text("الأدوات المتوفرة لديك حالياً", style = MaterialTheme.typography.titleMedium, color = Navy900)
        FlowRow(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            KhatwatCatalog.toolOptions.forEach { opt ->
                SelectablePillChip(
                    label = opt.label,
                    selected = opt.id in profile.tools,
                    onClick = { onToggleTool(opt.id) },
                    modifier = Modifier.testTag("tool_chip_${opt.id}")
                )
            }
        }

        OutlinedTextField(
            value = profile.city,
            onValueChange = onUpdateCity,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("city_input"),
            label = { Text("المدينة أو المنطقة (اختياري)") },
            placeholder = { Text("مثال: صنعاء، عدن، تعز، المكلا...") },
            singleLine = true,
            shape = RoundedCornerShape(12.dp)
        )

        Surface(
            shape = RoundedCornerShape(12.dp),
            color = PureWhite,
            border = BorderStroke(1.dp, BorderSubtle),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(12.dp)) {
                Text(
                    text = if (showOptionalAi) "إخفاء خيار Gemini المجاني الاختياري ▲" else "خيار إضافي مجاني: تعزيز الصياغة عبر Gemini (اختياري) ▼",
                    style = MaterialTheme.typography.labelLarge,
                    color = Navy800,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showOptionalAi = !showOptionalAi }
                        .padding(vertical = 4.dp)
                        .testTag("optional_gemini_toggle")
                )
                if (showOptionalAi) {
                    Spacer(Modifier.height(8.dp))
                    Text(
                        text = "التطبيق يعمل محلياً ومجاناً 100% دون إنترنت. هذا الخيار إضافي فقط إن توفر لديك مفتاح Google AI Studio مجاني.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = TextSecondary
                    )
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.clickable {
                            onToggleOptionalGemini(!useOptionalGemini, optionalGeminiKey)
                        }
                    ) {
                        Checkbox(
                            checked = useOptionalGemini,
                            onCheckedChange = { checked -> onToggleOptionalGemini(checked, optionalGeminiKey) }
                        )
                        Text("محاولة التحسين عبر Gemini عند توفر الإنترنت", style = MaterialTheme.typography.bodyMedium)
                    }
                    if (useOptionalGemini) {
                        OutlinedTextField(
                            value = optionalGeminiKey,
                            onValueChange = { onToggleOptionalGemini(true, it) },
                            modifier = Modifier.fillMaxWidth(),
                            label = { Text("مفتاح Google AI Studio المجاني (اختياري)") },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }
    }
}
