package com.example.domain

import java.util.concurrent.atomic.AtomicLong

class LocalPlanAnalyzer {

    companion object {
        private val planSequence = AtomicLong(0L)
    }

    private data class Blueprint(
        val id: String,
        val title: String,
        val summary: String,
        val workMode: String,
        val workModeLabel: String,
        val minYer: Long,
        val maxRecommendedYer: Long,
        val requiredTools: List<String>,
        val skills: List<String>,
        val interests: List<String>,
        val keywords: List<String>,
        val baseStartupCosts: List<CostItem>,
        val monthlyExpense: String,
        val monthlyRevenue: String,
        val breakEven: String,
        val steps: List<ExecutionStep>,
        val marketing: MarketingPlan
    )

    private data class RevisionDirectives(
        val wantsLowerCost: Boolean,
        val wantsRemote: Boolean,
        val wantsHome: Boolean,
        val wantsPhoneOnly: Boolean,
        val wantsWhatsappFocus: Boolean,
        val rawNote: String
    )

    private val blueprints = listOf(
        Blueprint(
            id = "social_media_clinic",
            title = "إدارة حسابات التواصل للمتاجر والمشاريع المحلية",
            summary = "تقديم باقات شهرية لإدارة صفحات المتاجر والمطاعم والأسر المنتجة عبر إنستغرام وواتساب وفيسبوك، من جدولة المنشورات إلى الرد على الاستفسارات.",
            workMode = "remote",
            workModeLabel = "عن بُعد بالكامل",
            minYer = 0L,
            maxRecommendedYer = 35_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("social_media", "writing", "design", "sales"),
            interests = listOf("digital_services", "creative_media", "ecommerce"),
            keywords = listOf("انستغرام", "فيسبوك", "واتساب", "تسويق", "متاجر", "سوشيال", "تصميم"),
            baseStartupCosts = listOf(
                CostItem("باقة إنترنت شهرية للعمل", "5,000 – 12,000 ر.ي"),
                CostItem("أدوات مجانية (Canva + Meta Business)", "0 ر.ي (مجاني)")
            ),
            monthlyExpense = "8,000 – 15,000 ر.ي (إنترنت واتصالات)",
            monthlyRevenue = "45,000 – 130,000 ر.ي (لـ 2 إلى 4 عملاء شهرياً)",
            breakEven = "من الشهر الأول لعدم وجود تكلفة تأسيس ثابتة",
            steps = listOf(
                ExecutionStep("smc_1", "تجهيز ملف أعمال مصغر من 3 نماذج", "صمّم 3 منشورات تجريبية لمتجر محلي لإثبات أسلوبك في الكتابة والتنسيق.", "اليوم 1 - 2"),
                ExecutionStep("smc_2", "تحديد باقتين واضحتين بأسعار مناسبة", "أنشئ باقة بداية (12 منشوراً شهرياً + تنسيق واتساب) وباقة متقدمة لتسهيل قرار العميل.", "اليوم 3"),
                ExecutionStep("smc_3", "حصر 20 متجراً ومشروعاً محلياً ضعيف الحضور", "ابحث في مدينتك عن مشاريع لديها منتج جيد لكن صفحاتها غير نشطة.", "اليوم 4 - 5"),
                ExecutionStep("smc_4", "تقديم عرض تجربة لأسبوع أو خصم افتتاحي", "تواصل برسالة مختصرة ومحترفة تشرح فيها كيف ستنظم حضورهم وتزيد مبيعاتهم.", "الأسبوع 2"),
                ExecutionStep("smc_5", "تنظيم جدول نشر أسبوعي وتقارير نتائج", "سلّم العميل خطة أسبوعية واضحة وتابع رسائل الزبائن وحصيلة التفاعل.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "المتاجر الصغيرة، المطاعم، العيادات، والأسر المنتجة في المدن اليمنية.",
                channels = listOf("رسائل مباشرة على إنستغرام وفيسبوك", "واتساب الأعمال", "مجموعات رواد الأعمال المحلية"),
                firstWeekActions = "أرسل 10 رسائل مخصصة يومياً تتضمن ملاحظة تحسين مجانية حقيقية لحساب كل متجر.",
                pricingTip = "ابدأ بسعر شهري مرن بالريال اليمني لأول عميلين مقابل السماح بعرض أعمالهم في معرضك."
            )
        ),
        Blueprint(
            id = "canva_quick_design",
            title = "استوديو التصميم السريع للهويات ومنشورات السوشيال ميديا",
            summary = "تصميم الشعارات البسيطة، قوائم الطعام (Menu)، بطاقات التهنئة، وإعلانات المتاجر بالاعتماد على الهاتف أو اللابتوب دون تكلفة مالية.",
            workMode = "remote",
            workModeLabel = "عن بُعد بالكامل",
            minYer = 0L,
            maxRecommendedYer = 30_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("design", "photography", "social_media"),
            interests = listOf("creative_media", "digital_services"),
            keywords = listOf("تصميم", "شعار", "لوجو", "منشورات", "بوستر", "كانفا", "هوية"),
            baseStartupCosts = listOf(
                CostItem("حساب مجاني في Canva / Figma", "0 ر.ي (مجاني)"),
                CostItem("باقة إنترنت لرفع الملفات والبحث", "5,000 – 10,000 ر.ي")
            ),
            monthlyExpense = "5,000 – 12,000 ر.ي",
            monthlyRevenue = "40,000 – 120,000 ر.ي (حسب عدد الطلبات الأسبوعية)",
            breakEven = "فوري مع أول طلبين تصميم",
            steps = listOf(
                ExecutionStep("cqd_1", "بناء معرض مصغر من 6 تصاميم متنوعة", "صمّم قائمة طعام، إعلان عروض، وشعاراً مبسطاً واحفظها في قناة تيليجرام منظمة.", "اليوم 1 - 3"),
                ExecutionStep("cqd_2", "تجهيز قوالب سريعة للتسليم خلال 24 ساعة", "رتّب ألواناً وخطوطاً عربية متناسقة لتقليل وقت تنفيذ الطلب الواحد.", "اليوم 4"),
                ExecutionStep("cqd_3", "إطلاق باقة تأسيس للمتاجر الجديدة", "اجمع 5 تصاميم إعلانية بسعر باقة أوفر من طلب كل تصميم منفرداً.", "الأسبوع 1"),
                ExecutionStep("cqd_4", "الاتفاق مع مطبعة محلية لإحالة العملاء", "تعاون مع مطبعة قريبة لتحويل عملاء الطباعة الذين يحتاجون تصميماً أولياً.", "الأسبوع 2 - 3")
            ),
            marketing = MarketingPlan(
                targetAudience = "أصحاب المتاجر الإلكترونية، المطابع الصغيرة، الأكاديميات، والمشاريع المنزلية.",
                channels = listOf("قنوات تيليجرام المهنية", "مجموعات فيسبوك التجارية", "حالات واتساب"),
                firstWeekActions = "صمّم إعادة تخيل مجانية لإعلان متجر معروف محلياً وشاركه كدراسة حالة جذابة.",
                pricingTip = "قدّم تسعيرة واضحة حسب الباقة (تصميم مفرد / باقة 5 تصاميم) لتسريع الاتفاق."
            )
        ),
        Blueprint(
            id = "copywriting_whatsapp_catalog",
            title = "كتابة المحتوى التجاري وتجهيز كتالوجات واتساب للمتاجر",
            summary = "مساعدة المتاجر على كتابة أوصاف منتجات مقنعة، نصوص إعلانية قصيرة، وترتيب كتالوج واتساب الأعمال بشكل احترافي يزيد التحويل.",
            workMode = "remote",
            workModeLabel = "عن بُعد بالكامل",
            minYer = 0L,
            maxRecommendedYer = 20_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("writing", "sales", "social_media", "translation"),
            interests = listOf("digital_services", "ecommerce", "creative_media"),
            keywords = listOf("كتابة", "محتوى", "إعلانات", "واتساب", "كتالوج", "وصف", "تسويق"),
            baseStartupCosts = listOf(
                CostItem("لا يتطلب رأس مال — الهاتف والإنترنت فقط", "0 – 6,000 ر.ي")
            ),
            monthlyExpense = "4,000 – 8,000 ر.ي",
            monthlyRevenue = "35,000 – 95,000 ر.ي",
            breakEven = "فوري من أول مشروع كتابة",
            steps = listOf(
                ExecutionStep("cwc_1", "تعلّم صياغة 3 قوالب كتابة بيعية قصيرة", "تدرّب على بنية: مشكلة العميل -> الميزة الرئيسية -> السعر الواضح -> دعوة للطلب.", "اليوم 1 - 2"),
                ExecutionStep("cwc_2", "إعداد نموذج عملي لكتالوج واتساب متكامل", "رتّب 8 منتجات افتراضية مع عناوين جذابة ومواصفات مختصرة.", "اليوم 3 - 4"),
                ExecutionStep("cwc_3", "استهداف البائعين عبر واتساب وفيسبوك", "ابحث عن بائعي الملابس والعطور والأدوات المنزلية ممن يكتبون نصوصاً مبعثرة.", "الأسبوع 2"),
                ExecutionStep("cwc_4", "تقديم باقة تجهيز كتالوج + تحديث شهري", "حوّل الخدمة من مهمة عابرة إلى دخل متكرر مع كل موسم وعرض جديد.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "البائعون عبر واتساب وإنستغرام الذين يملكون منتجات جيدة ويفتقرون للصياغة البيعية.",
                channels = listOf("واتساب المباشر", "مجموعات التجارة المحلية", "التوصيات الشخصية"),
                firstWeekActions = "أعد صياغة وصف منتج واحد لخمسة متاجر وأرسله لهم كعينة مجانية تظهر الفرق.",
                pricingTip = "سعّر بناءً على حجم الباقة (مثلاً باقة 15 وصف منتج + رسالة ترحيب آلية)."
            )
        ),
        Blueprint(
            id = "short_video_reels",
            title = "مونتاج مقاطع الريلز والشورتس للمتاجر وصنّاع المحتوى",
            summary = "تحويل مقاطع الفيديو الخام المصورة بالهاتف إلى فيديوهات قصيرة جذابة مع نصوص عربية ومؤثرات صوتية لزيادة مشاهدات المتاجر.",
            workMode = "remote",
            workModeLabel = "عن بُعد بالكامل",
            minYer = 0L,
            maxRecommendedYer = 30_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("video_edit", "photography", "social_media", "design"),
            interests = listOf("creative_media", "digital_services"),
            keywords = listOf("مونتاج", "فيديو", "ريلز", "تيك توك", "شورتس", "تصوير"),
            baseStartupCosts = listOf(
                CostItem("تطبيق مونتاج مجاني على الهاتف (CapCut)", "0 ر.ي"),
                CostItem("باقة إنترنت لرفع المقاطع", "6,000 – 14,000 ر.ي")
            ),
            monthlyExpense = "6,000 – 15,000 ر.ي",
            monthlyRevenue = "50,000 – 145,000 ر.ي",
            breakEven = "فوري عند إتمام أول 3 مقاطع مدفوعة",
            steps = listOf(
                ExecutionStep("svr_1", "إنتاج 4 مقاطع قصيرة نماذج أعمال", "حرّر مقاطع تعليمية وتجارية سريعة الإيقاع مع نصوص عربية واضحة ومقروءة.", "اليوم 1 - 3"),
                ExecutionStep("svr_2", "تجهيز دليل تصوير مبسط للعميل", "ورقة نصائح بسيطة تضمن إرسال العميل لك لقطات واضحة الإضاءة وسهلة المونتاج.", "اليوم 4"),
                ExecutionStep("svr_3", "عرض باقة 8 مقاطع شهرية بسعر مشجع", "استهدف المطاعم ومحلات الحلويات ومدربي الدورات.", "الأسبوع 2"),
                ExecutionStep("svr_4", "الالتزام بتسليم أول نسخة خلال 48 ساعة", "سرعة التسليم تبني سمعة قوية وتضمن استمرار العميل.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "المتاجر الشبابية، المقاهي، المدربون، وصنّاع المحتوى الصاعدون.",
                channels = listOf("إنستغرام ريلز", "تيك توك", "حالات واتساب"),
                firstWeekActions = "انشر مقطعاً يقارن بين فيديو خام وفيديو بعد المونتاج لجذب العملاء بصرياً.",
                pricingTip = "قدّم تسعيرة للمقطع الواحد وأخرى أوفر لباقة 8 أو 12 مقطعاً في الشهر."
            )
        ),
        Blueprint(
            id = "landing_pages_web",
            title = "تصميم صفحات هبوط وروابط تعريفية للمتاجر والمحترفين",
            summary = "بناء صفحات ويب خفيفة وسريعة باللغة العربية تجمع روابط المتجر ومنتجاته وأزرار الطلب المباشر عبر واتساب، باستضافات مجانية تماماً.",
            workMode = "remote",
            workModeLabel = "عن بُعد بالكامل",
            minYer = 0L,
            maxRecommendedYer = 25_000L,
            requiredTools = listOf("laptop", "internet"),
            skills = listOf("programming", "design", "writing"),
            interests = listOf("digital_services", "ecommerce", "tech_repair"),
            keywords = listOf("برمجة", "موقع", "صفحة", "ويب", "روابط", "متجر", "كود"),
            baseStartupCosts = listOf(
                CostItem("استضافة مجانية (GitHub Pages / Cloudflare Pages)", "0 ر.ي"),
                CostItem("باقة إنترنت", "6,000 – 12,000 ر.ي")
            ),
            monthlyExpense = "6,000 – 12,000 ر.ي",
            monthlyRevenue = "60,000 – 180,000 ر.ي",
            breakEven = "من أول صفحة هبوط مباعة",
            steps = listOf(
                ExecutionStep("lpw_1", "تجهيز 3 قوالب عربية RTL احترافية", "قالب لمتجر مرتبط بواتساب، قالب لمطعم (QR Menu)، وقالب سيرة ذاتية.", "الأسبوع 1"),
                ExecutionStep("lpw_2", "نشر القوالب كمعاينة حية مجانية", "ارفعها على استضافة مجانية ليرى العميل الصفحة على هاتفه فوراً.", "نهاية الأسبوع 1"),
                ExecutionStep("lpw_3", "التواصل مع متاجر تبيع عبر الرسائل العشوائية", "اشرح كيف تسهّل الصفحة استقبال الطلبات وتقلل ضياع الأسئلة المتكررة.", "الأسبوع 2 - 3"),
                ExecutionStep("lpw_4", "إضافة خدمة الصيانة وتحديث الأسعار", "اجعل التعديلات الموسمية باشتراك رمزي شهري.", "الأسبوع 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "المتاجر النشطة على إنستغرام، المطاعم، المكاتب الخدمية، والمستقلين.",
                channels = listOf("فيسبوك ولينكدإن", "رسائل مباشرة للمتاجر", "العلاقات الجامعية"),
                firstWeekActions = "اعرض تحويل قائمة أسعار مطعم أو متجر معروف في حيك إلى رابط QR تجريبي مجاني.",
                pricingTip = "حدّد السعر حسب القالب الجاهز مقابل التصميم المخصص بالكامل."
            )
        ),
        Blueprint(
            id = "online_local_tutoring",
            title = "التدريس الخصوصي والدورات المصغرة (حضوري أو أونلاين)",
            summary = "تقديم دروس تقوية مدرسية أو جامعية أو تدريب عملي في مهارة تتقنها (لغات، رياضيات، حاسوب، تصميم) لمجموعات صغيرة.",
            workMode = "flexible",
            workModeLabel = "مرن (عن بُعد أو محلي)",
            minYer = 0L,
            maxRecommendedYer = 20_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("teaching", "translation", "programming", "writing"),
            interests = listOf("education", "digital_services"),
            keywords = listOf("تدريس", "شرح", "دورات", "طلاب", "لغة", "تقوية", "تعليم"),
            baseStartupCosts = listOf(
                CostItem("تجهيز ملخصات PDF مجانية وتجربة الشرح", "0 – 10,000 ر.ي")
            ),
            monthlyExpense = "4,000 – 12,000 ر.ي (إنترنت ومطبوعات بسيطة)",
            monthlyRevenue = "40,000 – 140,000 ر.ي (لـ 4 إلى 10 طلاب)",
            breakEven = "من الأسبوع الأول عند تسجيل أول مجموعة",
            steps = listOf(
                ExecutionStep("olt_1", "تحديد مادة أو مهارة واحدة مطلوبة جداً", "اختر موضوعاً محدداً مثل: أساسيات الإنجليزية، رياضيات الثانوية، أو Excel.", "اليوم 1 - 2"),
                ExecutionStep("olt_2", "تصميم منهج عملي من 8 حصص وملخص PDF", "قسّم المادة إلى أهداف قصيرة واضحة ليشعر الطالب بالتقدم السريع.", "اليوم 3 - 5"),
                ExecutionStep("olt_3", "تقديم حصة تعريفية مجانية قصيرة", "ادعُ الطلاب عبر المجموعات التعليمية لتجربة أسلوبك قبل التسجيل.", "الأسبوع 2"),
                ExecutionStep("olt_4", "فتح مجموعات صغيرة (3–5 طلاب) بسعر ميسّر", "المجموعات الصغيرة تخفف السعر على الطالب وتزيد عائد الساعة للمعلم.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "طلاب المدارس والجامعات وأولياء الأمور الباحثين عن تقوية مركزة.",
                channels = listOf("مجموعات واتساب وتيليجرام الطلابية", "مكتبات التصوير القريبة", "التوصية العائلية"),
                firstWeekActions = "شارك ملخصاً مجانياً قيّماً من صفحتين يحل أصعب نقطة في المادة وأضف رقمك في نهايته.",
                pricingTip = "قدّم خصماً بسيطاً عند تسجيل طالبين معاً (أخوين أو صديقين)."
            )
        ),
        Blueprint(
            id = "whatsapp_brokerage",
            title = "الوساطة التجارية والتسويق بالعمولة للمنتجات المحلية",
            summary = "الربط بين التجار والموردين المحليين والزبائن عبر واتساب وفيسبوك مقابل عمولة متفق عليها على كل بيعة ناجحة، دون شراء مخزون.",
            workMode = "flexible",
            workModeLabel = "مرن (هاتف + ميداني خفيف)",
            minYer = 0L,
            maxRecommendedYer = 25_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("sales", "social_media", "writing", "photography"),
            interests = listOf("ecommerce", "local_services"),
            keywords = listOf("وساطة", "عمولة", "بيع", "تجارة", "واتساب", "تسويق", "شراء"),
            baseStartupCosts = listOf(
                CostItem("رصيد اتصال وإنترنت فقط (لا حاجة لشراء بضاعة)", "3,000 – 10,000 ر.ي")
            ),
            monthlyExpense = "5,000 – 12,000 ر.ي",
            monthlyRevenue = "45,000 – 150,000 ر.ي (حسب حركة المبيعات والعمولة)",
            breakEven = "فوري من أول عملية بيع ناجحة",
            steps = listOf(
                ExecutionStep("wb_1", "اختيار قطاع واحد واضح (إلكترونيات، ملابس، عسل...)", "التخصص يمنحك ثقة أسرع عند المشترين والموردين معاً.", "اليوم 1 - 2"),
                ExecutionStep("wb_2", "الاتفاق مع 3 موردين موثوقين على نسبة العمولة", "وثّق السعر الأساسي وجودة الضمان ومناطق التوصيل قبل النشر.", "اليوم 3 - 5"),
                ExecutionStep("wb_3", "تصوير المنتجات بوضوح وتجهيز كتالوج واتساب", "اكتب المواصفات بدقة وشفافية وتجنب المبالغة.", "الأسبوع 2"),
                ExecutionStep("wb_4", "متابعة التوصيل وتحصيل العمولة أسبوعياً", "احرص على رضا المشتري بعد الاستلام لضمان عودته.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "المتسوقون عبر الهاتف الباحثون عن أسعار جملة مخفضة أو منتجات مضمونة المصدر.",
                channels = listOf("حالات ومجموعات واتساب", "المجموعات المحلية في فيسبوك", "قناة عروض تيليجرام"),
                firstWeekActions = "انشر 5 عروض حقيقية بأسعار منافسة وصور واضحة وخدمة استفسار سريعة.",
                pricingTip = "لا تبالغ في هامش العمولة في البداية؛ سرعة دوران البيع تبني قاعدة زبائن ثابتة."
            )
        ),
        Blueprint(
            id = "home_bakery_sweets",
            title = "مشروع الحلويات والمعجنات المنزلية بالطلب المسبق",
            summary = "تحضير كيك المناسبات، المعجنات، أو الحلويات الشعبية والعصرية من مطبخ المنزل حسب الطلب المسبق فقط لتفادي الهدر.",
            workMode = "home",
            workModeLabel = "من المنزل بالطلب",
            minYer = 15_000L,
            maxRecommendedYer = 85_000L,
            requiredTools = listOf("workspace"),
            skills = listOf("cooking", "photography", "sales"),
            interests = listOf("food_beverage"),
            keywords = listOf("طبخ", "حلويات", "كيك", "معجنات", "أكل", "مطبخ", "منزل"),
            baseStartupCosts = listOf(
                CostItem("مكونات وتجارب أولية (دقيق، سكر، زبدة، شوكولاتة)", "18,000 – 32,000 ر.ي"),
                CostItem("علب تغليف وأكياس أنيقة للانطلاقة", "8,000 – 15,000 ر.ي")
            ),
            monthlyExpense = "حسب الطلبات (يُغطى من سعر الطلب + هامش الربح)",
            monthlyRevenue = "65,000 – 190,000 ر.ي (عند تنفيذ 12–25 طلباً شهرياً)",
            breakEven = "خلال 3 إلى 6 أسابيع مع الالتزام بالطلب المسبق",
            steps = listOf(
                ExecutionStep("hbs_1", "حصر القائمة في 3 أصناف متقنة فقط", "ابدأ بأصناف تعرف تكلفتها بالضبط وتستطيع تنفيذها بجودة ثابتة كل مرة.", "اليوم 1 - 2"),
                ExecutionStep("hbs_2", "حساب تكلفة الوصفة شاملة الغاز والتغليف", "لا تنسَ حساب تكلفة الكهرباء/الغاز والعلبة قبل تحديد السعر النهائي.", "اليوم 3"),
                ExecutionStep("hbs_3", "تحضير عينة للتذوق وتصويرها بإضاءة نهار", "الصورة الشهية الواضحة بجانب النافذة هي أقوى مسوّق لمنتجات الطعام.", "اليوم 4 - 5"),
                ExecutionStep("hbs_4", "إطلاق الطلب المسبق قبل 24 ساعة بعربون", "اعتمد الحجز المسبق لضمان عدم تلف أي مكونات.", "الأسبوع 2"),
                ExecutionStep("hbs_5", "تثبيت التوصيل الآمن وجمع آراء الزبائن", "اتفق مع مندوب توصيل موثوق أو خصص أوقات استلام محددة.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "الأسر في الحي، الموظفات، وطالبو ضيافة المناسبات الصغيرة والاجتماعات.",
                channels = listOf("حالات واتساب اليومية", "صفحة إنستغرام محلية", "مجموعات الأسر والحي"),
                firstWeekActions = "أرسل علب ضيافة مصغرة (تذوق) لـ 5 معارف مؤثرين مقابل نشر صورهم وتقييمهم.",
                pricingTip = "اضمن هامشاً لا يقل عن 35-45% فوق تكلفة المواد والتغليف لتغطية جهدك والغاز."
            )
        ),
        Blueprint(
            id = "gift_wrapping_favors",
            title = "تنسيق الهدايا وتوزيعات المناسبات من المنزل",
            summary = "تجهيز صناديق هدايا، بطاقات إهداء مخصصة، وتوزيعات أعراس ومواليد وتخرج بأسلوب مرتب حسب ميزانية كل زبون.",
            workMode = "home",
            workModeLabel = "من المنزل بالطلب",
            minYer = 15_000L,
            maxRecommendedYer = 80_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("crafts", "design", "photography", "sales"),
            interests = listOf("handmade", "creative_media"),
            keywords = listOf("هدايا", "تغليف", "مناسبات", "توزيعات", "حفلات", "يدوي"),
            baseStartupCosts = listOf(
                CostItem("خامات تغليف، شرائط، كراتين، ومقصات أساسية", "18,000 – 35,000 ر.ي"),
                CostItem("بطاقات مطبوعة بسيطة بشعارك", "4,000 – 8,000 ر.ي")
            ),
            monthlyExpense = "متغيرة حسب كمية الطلبات المحجوزة",
            monthlyRevenue = "55,000 – 160,000 ر.ي",
            breakEven = "خلال شهر واحد بعد تنفيذ 8-12 طلب تنسيق",
            steps = listOf(
                ExecutionStep("gwf_1", "تصميم 3 باقات هدايا بأسعار متفاوتة", "باقة اقتصادية، باقة متوسطة، وباقة فاخرة ليجد كل زبون ما يناسب ميزانيته.", "اليوم 1 - 3"),
                ExecutionStep("gwf_2", "الشراء من الجملة بعد تأكيد الطلب", "لا تكدّس مخزوناً كبيراً في البداية؛ اشترِ الخاص حسب الطلب.", "الأسبوع 1"),
                ExecutionStep("gwf_3", "تصوير فيديو قصير أثناء التغليف", "مقاطع التجهيز ترفع الثقة وتبرز الدقة في التفاصيل.", "الأسبوع 2"),
                ExecutionStep("gwf_4", "التنسيق مع محلات العطور أو الحلويات", "قدّم لهم خدمة التغليف المميز لمنتجاتهم.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "الشباب والأسر في مواسم التخرج والأعياد والخطوبة والمواليد.",
                channels = listOf("إنستغرام", "تيك توك", "حالات واتساب"),
                firstWeekActions = "جهّز صندوقين نموذجيين متكاملين وصورهما من زوايا متعددة للإطلاق.",
                pricingTip = "احسب سعر التغليف والجهد بشكل منفصل عن سعر الهدايا التي يختارها الزبون."
            )
        ),
        Blueprint(
            id = "handmade_accessories",
            title = "صناعة الإكسسوارات والمشغولات اليدوية المصغرة",
            summary = "تصميم وإنتاج أساور، سلاسل، ميداليات، أو مشغولات كروشيه/ريزن بكميات محدودة وبيعها أونلاين أو عبر البازارات المحلية.",
            workMode = "home",
            workModeLabel = "من المنزل",
            minYer = 12_000L,
            maxRecommendedYer = 65_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("crafts", "photography", "design", "sales"),
            interests = listOf("handmade", "ecommerce", "creative_media"),
            keywords = listOf("اكسسوارات", "خرز", "كروشيه", "حرف", "يدوية", "تطريز"),
            baseStartupCosts = listOf(
                CostItem("حزمة خامات أولية (خرز/خيوط/أقفال/زرادية)", "15,000 – 30,000 ر.ي"),
                CostItem("بطاقات عرض وأكياس شفافة", "3,000 – 7,000 ر.ي")
            ),
            monthlyExpense = "10,000 – 25,000 ر.ي لتجديد الخامات",
            monthlyRevenue = "45,000 – 130,000 ر.ي",
            breakEven = "خلال 4 إلى 6 أسابيع",
            steps = listOf(
                ExecutionStep("ha_1", "إنتاج مجموعة تأسيسية من 10 قطع متناسقة", "ركز على أسلوب واحد مميز (تراثي، شبابي بسيط، أو مخصص بالأسماء).", "الأسبوع 1"),
                ExecutionStep("ha_2", "تصوير القطع أثناء الارتداء وعلى خلفية نظيفة", "إظهار الحجم الحقيقي للقطعة يقلل تردد المشتري.", "نهاية الأسبوع 1"),
                ExecutionStep("ha_3", "فتح حساب عرض منظم وكتالوج واتساب", "اذكر السعر ومدة التجهيز بوضوح تحت كل صورة.", "الأسبوع 2"),
                ExecutionStep("ha_4", "وضع ركن عرض في مكتبة أو مقهى محلي", "تعاون بنظام العمولة لتوسيع الوصول للمشترين.", "الأسبوع 3 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "طالبات الجامعات والشباب والباحثون عن هدايا شخصية بأسعار معقولة.",
                channels = listOf("إنستغرام", "واتساب", "معارض ومبادرات طلابية"),
                firstWeekActions = "أضف ميزة كتابة الحرف أو الاسم على القطعة لرفع جاذبيتها كهدية.",
                pricingTip = "اضرب تكلفة الخامات × 2.5 كحد أدنى لتغطية ساعات العمل اليدوي والتسويق."
            )
        ),
        Blueprint(
            id = "smartphone_product_photo",
            title = "تصوير منتجات المتاجر والأسر المنتجة بالهاتف",
            summary = "زيارة المتاجر أو استلام المنتجات في المنزل لتصويرها بإضاءة احترافية وتعديلها بالهاتف لتظهر بصورة جذابة على صفحات البيع.",
            workMode = "local",
            workModeLabel = "ميداني / محلي",
            minYer = 15_000L,
            maxRecommendedYer = 70_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("photography", "design", "video_edit"),
            interests = listOf("creative_media", "ecommerce", "local_services"),
            keywords = listOf("تصوير", "منتجات", "صور", "كاميرا", "إضاءة", "هاتف"),
            baseStartupCosts = listOf(
                CostItem("حامل هاتف (Tripod) + عاكس إضاءة بسيط + خلفيات ورقية", "18,000 – 38,000 ر.ي"),
                CostItem("تطبيقات تعديل مجانية (Lightroom / Snapseed)", "0 ر.ي")
            ),
            monthlyExpense = "5,000 – 15,000 ر.ي (تنقل وخلفيات)",
            monthlyRevenue = "60,000 – 180,000 ر.ي",
            breakEven = "خلال 3 إلى 5 أسابيع",
            steps = listOf(
                ExecutionStep("spp_1", "تجهيز عدة تصوير متنقلة وخفيفة الوزن", "لوح خلفيات مزدوج (أبيض/خشبي) + رينج لايت أو عاكس إضاءة طبيعية.", "الأسبوع 1"),
                ExecutionStep("spp_2", "تصوير 10 منتجات منزلية كمعرض قبل وبعد", "أظهر الفرق بين صورة عادية وصورة منسقة ومعدلة باحتراف.", "الأسبوع 1"),
                ExecutionStep("spp_3", "طرح باقة تصوير 15 منتجاً بسعر تشجيعي", "مثالية لمشاريع العطور والحلويات والإكسسوارات والملابس.", "الأسبوع 2 - 3"),
                ExecutionStep("spp_4", "عرض إضافة مقاطع فيديو قصيرة للمنتج", "ارفع قيمة الجلسة بتصوير لقطات حركة سريعة.", "الأسبوع 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "المتاجر الإلكترونية المحلية، المطاعم، ومحلات العطور والملابس.",
                channels = listOf("إنستغرام", "التواصل المباشر مع الصفحات ذات الصور الضعيفة", "واتساب"),
                firstWeekActions = "اختر 3 متاجر محلية واعرض تصوير 3 منتجات مجاناً لإقناعهم بالباقة الكاملة.",
                pricingTip = "سعّر الجلسة حسب عدد المنتجات (مثلاً 10 / 20 / 30 منتجاً)."
            )
        ),
        Blueprint(
            id = "hardware_phone_repair",
            title = "صيانة الهواتف الذكية السريعة (شاشات، بطاريات، منافذ شحن)",
            summary = "تقديم خدمة صيانة أساسية سريعة وموثوقة للبطاريات والشاشات ومنافذ الشحن من ركن منزلي مجهز أو بالاستلام والتسليم.",
            workMode = "local",
            workModeLabel = "محلي / استلام وتسليم",
            minYer = 85_000L,
            maxRecommendedYer = 320_000L,
            requiredTools = listOf("workspace"),
            skills = listOf("phone_repair", "home_tech", "sales"),
            interests = listOf("tech_repair", "local_services"),
            keywords = listOf("صيانة", "شاشات", "بطارية", "هواتف", "تلفونات", "تصليح"),
            baseStartupCosts = listOf(
                CostItem("حقيبة عدة صيانة (مفكات، كاوية لحام، هيتر، مادة لاصقة)", "55,000 – 120,000 ر.ي"),
                CostItem("مخزون بسيط من كابلات وقطع استهلاكية سريعة", "30,000 – 80,000 ر.ي")
            ),
            monthlyExpense = "توفير قطع الغيار حسب كل طلب",
            monthlyRevenue = "120,000 – 340,000 ر.ي",
            breakEven = "خلال 6 إلى 10 أسابيع",
            steps = listOf(
                ExecutionStep("hpr_1", "تجهيز طاولة عمل آمنة وإضاءة قوية", "ترتيب البراغي وفرش عازل للكهرباء الساكنة يحمي أجهزة العملاء.", "الأسبوع 1"),
                ExecutionStep("hpr_2", "الاتفاق مع تاجر قطع غيار جملة موثوق", "تأكد من وجود ضمان فحص قبل التركيب النهائي.", "الأسبوع 1"),
                ExecutionStep("hpr_3", "توثيق حالة الجهاز وتقديم ضمان 14 يوماً", "الضمان القصير على التركيب يمنح العميل ثقة تفوق الورش التقليدية.", "الأسبوع 2 - 4")
            ),
            marketing = MarketingPlan(
                targetAudience = "سكان الحي، طلاب الجامعات، وأصحاب الأعمال الذين يحتاجون إصلاحاً سريعاً.",
                channels = listOf("خرائط جوجل", "واتساب الحي", "التعاون مع محلات الإكسسوارات"),
                firstWeekActions = "اطرح خدمة تبديل البطارية أو الشاشة مع الاستلام والتسليم داخل الحي.",
                pricingTip = "وضّح للزبون خيارات جودة القطعة وسعر كل خيار قبل البدء بالعمل."
            )
        ),
        Blueprint(
            id = "home_quick_maintenance",
            title = "خدمة الصيانة المنزلية السريعة (كهرباء، سباكة، أجهزة بسيطة)",
            summary = "الاستجابة السريعة للأعطال المنزلية اليومية في الحي (مفاتيح كهرباء، صنابير، مراوح، تمديدات بسيطة) بتسعيرة واضحة وموثوقة.",
            workMode = "local",
            workModeLabel = "ميداني محلي",
            minYer = 60_000L,
            maxRecommendedYer = 250_000L,
            requiredTools = listOf("smartphone"),
            skills = listOf("home_tech", "phone_repair", "sales"),
            interests = listOf("local_services", "tech_repair"),
            keywords = listOf("صيانة منزلية", "كهرباء", "سباكة", "إصلاح", "أجهزة"),
            baseStartupCosts = listOf(
                CostItem("حقيبة عدة كهربائية وسباكة متكاملة + جهاز فحص", "45,000 – 110,000 ر.ي"),
                CostItem("قطع غيار أساسية (قواطع، تيب، جلد، مفاتيح)", "15,000 – 45,000 ر.ي")
            ),
            monthlyExpense = "15,000 – 35,000 ر.ي (تنقل وتجديد قطع)",
            monthlyRevenue = "110,000 – 320,000 ر.ي",
            breakEven = "خلال 4 إلى 6 أسابيع",
            steps = listOf(
                ExecutionStep("hqm_1", "حصر الخدمات الآمنة التي تتقنها 100%", "ابدأ بالأعطال الشائعة السريعة ولا تغامر بأعمال تحتاج معدات ثقيلة.", "الأسبوع 1"),
                ExecutionStep("hqm_2", "إعلان رقم الصيانة في بقالات ومجموعات الحي", "الأسر تفضل فني حي معروفاً ومنظماً يسهل التواصل معه على واتساب.", "الأسبوع 1 - 2"),
                ExecutionStep("hqm_3", "إرسال فاتورة واضحة وتقرير صور قبل وبعد", "الشفافية في سعر القطعة وأجرة اليد تصنع سمعة ذهبية.", "مستمر")
            ),
            marketing = MarketingPlan(
                targetAudience = "الأسر، الشقق المفروشة، المكاتب، والمدارس الخاصة في المنطقة.",
                channels = listOf("ملصقات صغيرة في الحي", "واتساب الجيران", "التوصيات المباشرة"),
                firstWeekActions = "جهّز قائمة بـ 10 فحوصات سلامة منزلية واعرض فحصاً دورياً للمكاتب والشقق.",
                pricingTip = "حدد أجرة زيارة وفحص واضحة تُخصم في حال الموافقة على الإصلاح."
            )
        )
    )

    fun analyze(profile: QuestionnaireProfile, revisionNote: String = ""): BusinessPlanBundle {
        val directives = parseDirectives(revisionNote)
        val rawMaxYer = profile.getBudgetMaxYer()
        val effectiveMaxYer = if (directives.wantsLowerCost) minOf(rawMaxYer, 20_000L) else rawMaxYer
        val userTools = profile.tools.toSet()
        val hasLaptop = userTools.contains("laptop") && !directives.wantsPhoneOnly
        val hasWorkspace = userTools.contains("workspace")
        val combinedNotes = normalizeText(
            "${profile.customSkills.joinToString(" ")} ${profile.passionNote} $revisionNote"
        )

        val ranked = blueprints.mapIndexed { idx, bp ->
            var score = 10

            score += bp.skills.count { it in profile.skills } * 24
            score += bp.interests.count { it in profile.interests } * 16

            bp.keywords.forEach { kw ->
                if (combinedNotes.contains(normalizeText(kw))) {
                    score += 12
                }
            }

            if (bp.minYer <= effectiveMaxYer) {
                score += 22
                if (effectiveMaxYer == 0L && bp.minYer == 0L) score += 18
            } else {
                val gap = bp.minYer - effectiveMaxYer
                score -= if (gap > 50_000L) 60 else 32
            }

            val targetLoc = when {
                directives.wantsRemote -> "remote"
                directives.wantsHome -> "home"
                else -> profile.locationPreference
            }
            when (targetLoc) {
                "remote" -> score += when (bp.workMode) {
                    "remote" -> 26
                    "flexible" -> 10
                    else -> -42
                }
                "home" -> score += when (bp.workMode) {
                    "home", "remote" -> 20
                    "flexible" -> 12
                    else -> -18
                }
                "local" -> score += when (bp.workMode) {
                    "local", "flexible" -> 20
                    "home" -> 8
                    else -> 0
                }
                else -> score += 8
            }

            if (bp.requiredTools.contains("laptop") && !hasLaptop) score -= 48
            if (bp.requiredTools.contains("workspace") && !hasWorkspace) score -= 18
            if (directives.wantsPhoneOnly && !bp.requiredTools.contains("laptop")) score += 15

            if (profile.hoursId == "lt8" && bp.workMode == "local" && bp.minYer >= 80_000L) {
                score -= 10
            } else if (profile.hoursId == "25_plus") {
                score += 5
            }

            Triple(bp, score, idx)
        }.sortedWith(compareByDescending<Triple<Blueprint, Int, Int>> { it.second }.thenBy { it.third })
            .take(3)

        val now = System.currentTimeMillis()
        val ideas = ranked.mapIndexed { rankIdx, (bp, _, _) ->
            BusinessIdea(
                id = "${bp.id}_${rankIdx + 1}",
                rank = rankIdx + 1,
                title = bp.title,
                summary = bp.summary,
                workModeLabel = bp.workModeLabel,
                reasons = buildReasons(bp, profile, directives, effectiveMaxYer),
                financials = FinancialEstimate(
                    startupRangeLabel = if (bp.minYer == 0L) {
                        "0 – 12,000 ر.ي (اختياري للإنترنت فقط)"
                    } else {
                        "${KhatwatCatalog.formatYer(bp.minYer)} – ${KhatwatCatalog.formatYer(bp.maxRecommendedYer)} ر.ي"
                    },
                    startupItems = adaptStartupCosts(bp, effectiveMaxYer, directives),
                    monthlyExpense = bp.monthlyExpense,
                    monthlyRevenue = bp.monthlyRevenue,
                    breakEven = bp.breakEven
                ),
                steps = bp.steps.map { it.copy(completed = false) },
                marketing = adaptMarketing(bp, profile, directives)
            )
        }

        return BusinessPlanBundle(
            id = "plan_${now}_${planSequence.incrementAndGet()}",
            createdAt = now,
            updatedAt = now,
            profile = profile,
            source = "local",
            sourceLabel = "التحليل المحلي المجاني (يعمل دون إنترنت)",
            revisionNote = directives.rawNote,
            ideas = ideas
        )
    }

    private fun normalizeText(input: String): String = input.trim().lowercase()
        .replace("أ", "ا")
        .replace("إ", "ا")
        .replace("آ", "ا")
        .replace("ة", "ه")
        .replace("ى", "ي")

    private fun parseDirectives(revisionNote: String): RevisionDirectives {
        val text = normalizeText(revisionNote)
        return RevisionDirectives(
            wantsLowerCost = text.contains("اقل تكلفه") || text.contains("بدون راس مال") ||
                text.contains("مجاني") || text.contains("ارخص") || text.contains("صفر"),
            wantsRemote = text.contains("عن بعد") || text.contains("اونلاين") ||
                text.contains("انترنت") || text.contains("بدون خروج"),
            wantsHome = text.contains("منزل") || text.contains("بيت"),
            wantsPhoneOnly = text.contains("هاتف فقط") || text.contains("جوال فقط") ||
                text.contains("بدون لابتوب"),
            wantsWhatsappFocus = text.contains("واتساب") || text.contains("انستغرام"),
            rawNote = revisionNote.trim()
        )
    }

    private fun buildReasons(
        bp: Blueprint,
        profile: QuestionnaireProfile,
        directives: RevisionDirectives,
        maxYer: Long
    ): List<String> {
        val reasons = mutableListOf<String>()
        val matchedSkills = bp.skills
            .filter { it in profile.skills }
            .mapNotNull { id -> KhatwatCatalog.skillOptions.find { it.id == id }?.label }

        when {
            matchedSkills.isNotEmpty() ->
                reasons.add("تستثمر مباشرة مهاراتك في: ${matchedSkills.take(3).joinToString("، ")}.")
            profile.customSkills.isNotEmpty() ->
                reasons.add("تتقاطع مع مهارتك المضافة (${profile.customSkills.joinToString("، ")}) وقابلة للتنفيذ السريع.")
            else ->
                reasons.add("لا تتطلب خبرة معقدة مسبقاً ويمكن إتقان خطواتها الأولى خلال أيام.")
        }

        when {
            maxYer == 0L && bp.minYer == 0L ->
                reasons.add("مناسبة تماماً لميزانية 0 ر.ي بدون الحاجة لشراء مخزون أو استئجار محل.")
            bp.minYer <= maxYer ->
                reasons.add("تكلفتها التأسيسية تندرج ضمن ميزانيتك المعلنة (${profile.getBudgetLabel()}).")
            else ->
                reasons.add("يمكن تقليص بدايتها بالاعتماد على الطلب المسبق لتقترب من ميزانيتك.")
        }

        if (profile.locationPreference == "remote" && bp.workMode == "remote") {
            reasons.add("تحقق رغبتك في العمل عن بُعد بالكامل من أي مكان.")
        } else if (profile.locationPreference == "home" && (bp.workMode == "home" || bp.workMode == "remote")) {
            reasons.add("تُدار من المنزل دون الحاجة لتكاليف إيجار أو محل.")
        } else if (directives.wantsPhoneOnly && !bp.requiredTools.contains("laptop")) {
            reasons.add("يمكن البدء بتشغيلها وإدارتها عبر الهاتف الذكي فقط.")
        } else {
            val toolLabels = profile.tools
                .mapNotNull { id -> KhatwatCatalog.toolOptions.find { it.id == id }?.label }
            if (toolLabels.isNotEmpty()) {
                reasons.add("تستفيد من الأدوات المتوفرة لديك حالياً (${toolLabels.take(2).joinToString(" و")}).")
            }
        }

        if (directives.rawNote.isNotEmpty()) {
            reasons.add("مكيّفة مع ملاحظتك: \"${directives.rawNote}\".")
        }

        return reasons.take(4)
    }

    private fun adaptStartupCosts(
        bp: Blueprint,
        maxYer: Long,
        directives: RevisionDirectives
    ): List<CostItem> {
        if ((directives.wantsLowerCost || maxYer == 0L) && bp.minYer > 0L) {
            return listOf(
                CostItem("بدء بالطلب المسبق وعربون العميل قبل الشراء", "تقليص التكلفة بنسبة 50%+")
            ) + bp.baseStartupCosts
        }
        return bp.baseStartupCosts
    }

    private fun adaptMarketing(
        bp: Blueprint,
        profile: QuestionnaireProfile,
        directives: RevisionDirectives
    ): MarketingPlan {
        val channels = bp.marketing.channels.toMutableList()
        if (directives.wantsWhatsappFocus && channels.none { it.contains("واتساب") }) {
            channels.add(0, "حالات وقوائم واتساب الأعمال المباشرة")
        }
        val citySuffix = if (profile.city.trim().isNotEmpty()) {
            " (مع التركيز المبدئي على سوق ${profile.city.trim()})"
        } else {
            ""
        }
        return bp.marketing.copy(
            targetAudience = "${bp.marketing.targetAudience}$citySuffix",
            channels = channels.take(4)
        )
    }
}
