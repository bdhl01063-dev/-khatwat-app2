package com.example.domain

import android.util.Log
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeout
import org.json.JSONArray
import org.json.JSONObject
import java.io.OutputStreamWriter
import java.net.HttpURLConnection
import java.net.URL

interface PlanAnalyzer {
    suspend fun analyze(
        profile: QuestionnaireProfile,
        revisionNote: String = "",
        useOptionalGemini: Boolean = false,
        optionalApiKey: String = ""
    ): BusinessPlanBundle
}

/**
 * Offline-first analyzer: runs [LocalPlanAnalyzer] immediately by default.
 * Only attempts optional free-tier Gemini REST API when explicitly enabled with a key,
 * and falls back cleanly to local results on any error or timeout so the app never stops.
 */
class KhatwatPlanAnalyzer(
    private val localAnalyzer: LocalPlanAnalyzer = LocalPlanAnalyzer()
) : PlanAnalyzer {

    companion object {
        private const val TAG = "KhatwatPlanAnalyzer"
        private const val GEMINI_URL =
            "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
    }

    override suspend fun analyze(
        profile: QuestionnaireProfile,
        revisionNote: String,
        useOptionalGemini: Boolean,
        optionalApiKey: String
    ): BusinessPlanBundle {
        val localBundle = localAnalyzer.analyze(profile, revisionNote)
        val trimmedKey = optionalApiKey.trim()
        if (!useOptionalGemini || trimmedKey.isEmpty()) {
            return localBundle
        }

        return try {
            withTimeout(25_000L) {
                requestOptionalGemini(profile, revisionNote, trimmedKey, localBundle)
            }
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            Log.w(TAG, "Optional Gemini unavailable, using local analyzer fallback", e)
            localBundle.copy(
                fallbackNotice = "تعذر الاتصال بخدمة Gemini المجانية الاختيارية، لذلك تم اعتماد نتائج المحرك المحلي فوراً دون توقف."
            )
        }
    }

    private suspend fun requestOptionalGemini(
        profile: QuestionnaireProfile,
        revisionNote: String,
        apiKey: String,
        fallbackBundle: BusinessPlanBundle
    ): BusinessPlanBundle = withContext(Dispatchers.IO) {
        val skillLabels = profile.skills
            .mapNotNull { id -> KhatwatCatalog.skillOptions.find { it.id == id }?.label }
            .joinToString("، ")
        val interestLabels = profile.interests
            .mapNotNull { id -> KhatwatCatalog.interestOptions.find { it.id == id }?.label }
            .joinToString("، ")

        val prompt = """
أنت مستشار مشاريع صغيرة للشباب في اليمن. أعطِ 3 أفكار مشاريع عملية باللغة العربية الفصحى السهلة بصيغة JSON فقط، بالريال اليمني (YER)، دون وعود مضمونة:
المهارات: $skillLabels ${profile.customSkills.joinToString("، ")}
الاهتمامات: $interestLabels ${profile.passionNote}
الميزانية: ${profile.getBudgetLabel()}
طبيعة العمل: ${profile.getLocationLabel()}
المدينة: ${profile.city.ifBlank { "غير محددة" }}
${if (revisionNote.isNotBlank()) "ملاحظة التعديل: $revisionNote" else ""}

أعد كائن JSON يحتوي على مصفوفة "ideas" من 3 عناصر، كل عنصر فيه:
title, summary, workModeLabel, reasons (3 أسباب), startupRangeLabel, monthlyExpense, monthlyRevenue, breakEven, startupItems ({item, range}), steps ({title, description, timeframe}), marketing ({targetAudience, channels, firstWeekActions, pricingTip}).
        """.trimIndent()

        val connection = (URL("$GEMINI_URL?key=$apiKey").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            setRequestProperty("Content-Type", "application/json; charset=UTF-8")
            connectTimeout = 15_000
            readTimeout = 20_000
            doOutput = true
        }

        val requestBody = JSONObject().apply {
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", prompt))
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("responseMimeType", "application/json")
                put("temperature", 0.7)
            })
        }.toString()

        OutputStreamWriter(connection.outputStream, Charsets.UTF_8).use { writer ->
            writer.write(requestBody)
        }

        val statusCode = connection.responseCode
        if (statusCode !in 200..299) {
            throw IllegalStateException("HTTP $statusCode")
        }

        val responseText = connection.inputStream.bufferedReader(Charsets.UTF_8).use { it.readText() }
        val root = JSONObject(responseText)
        val rawJson = root.getJSONArray("candidates")
            .getJSONObject(0)
            .getJSONObject("content")
            .getJSONArray("parts")
            .getJSONObject(0)
            .getString("text")

        val parsed = JSONObject(rawJson)
        val ideasArray = parsed.getJSONArray("ideas")
        if (ideasArray.length() < 3) throw IllegalStateException("Incomplete ideas")

        val enhancedIdeas = (0 until 3).map { idx ->
            val obj = ideasArray.getJSONObject(idx)
            val fallbackIdea = fallbackBundle.ideas[idx]
            val reasonsArr = obj.optJSONArray("reasons")
            val reasons = if (reasonsArr != null && reasonsArr.length() > 0) {
                (0 until reasonsArr.length()).map { reasonsArr.getString(it) }
            } else {
                fallbackIdea.reasons
            }

            val itemsArr = obj.optJSONArray("startupItems")
            val startupItems = if (itemsArr != null && itemsArr.length() > 0) {
                (0 until itemsArr.length()).map { i ->
                    val itemObj = itemsArr.getJSONObject(i)
                    CostItem(
                        item = itemObj.optString("item", "بند تأسيسي"),
                        range = itemObj.optString("range", "تقدير تقريبي")
                    )
                }
            } else {
                fallbackIdea.financials.startupItems
            }

            val stepsArr = obj.optJSONArray("steps")
            val steps = if (stepsArr != null && stepsArr.length() > 0) {
                (0 until stepsArr.length()).map { s ->
                    val sObj = stepsArr.getJSONObject(s)
                    ExecutionStep(
                        id = "gem_${idx + 1}_step_${s + 1}",
                        title = sObj.optString("title", "خطوة ${s + 1}"),
                        description = sObj.optString("description", ""),
                        timeframe = sObj.optString("timeframe", "الأسبوع الأول"),
                        completed = false
                    )
                }
            } else {
                fallbackIdea.steps
            }

            val mktObj = obj.optJSONObject("marketing")
            val channelsArr = mktObj?.optJSONArray("channels")
            val channels = if (channelsArr != null && channelsArr.length() > 0) {
                (0 until channelsArr.length()).map { channelsArr.getString(it) }
            } else {
                fallbackIdea.marketing.channels
            }

            BusinessIdea(
                id = "gem_${idx + 1}_${System.currentTimeMillis()}",
                rank = idx + 1,
                title = obj.optString("title", fallbackIdea.title),
                summary = obj.optString("summary", fallbackIdea.summary),
                workModeLabel = obj.optString("workModeLabel", fallbackIdea.workModeLabel),
                reasons = reasons,
                financials = FinancialEstimate(
                    startupRangeLabel = obj.optString("startupRangeLabel", fallbackIdea.financials.startupRangeLabel),
                    startupItems = startupItems,
                    monthlyExpense = obj.optString("monthlyExpense", fallbackIdea.financials.monthlyExpense),
                    monthlyRevenue = obj.optString("monthlyRevenue", fallbackIdea.financials.monthlyRevenue),
                    breakEven = obj.optString("breakEven", fallbackIdea.financials.breakEven)
                ),
                steps = steps,
                marketing = MarketingPlan(
                    targetAudience = mktObj?.optString("targetAudience", fallbackIdea.marketing.targetAudience)
                        ?: fallbackIdea.marketing.targetAudience,
                    channels = channels,
                    firstWeekActions = mktObj?.optString("firstWeekActions", fallbackIdea.marketing.firstWeekActions)
                        ?: fallbackIdea.marketing.firstWeekActions,
                    pricingTip = mktObj?.optString("pricingTip", fallbackIdea.marketing.pricingTip)
                        ?: fallbackIdea.marketing.pricingTip
                )
            )
        }

        fallbackBundle.copy(
            source = "gemini_optional",
            sourceLabel = "معزز اختيارياً عبر Gemini المجاني (مع توافر العمل المحلي)",
            ideas = enhancedIdeas
        )
    }
}
