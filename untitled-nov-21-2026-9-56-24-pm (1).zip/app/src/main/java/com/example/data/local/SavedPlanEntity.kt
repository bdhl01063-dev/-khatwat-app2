package com.example.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey
import com.example.domain.BusinessPlanBundle
import com.example.domain.PlanJsonCodec

@Entity(tableName = "saved_plans")
data class SavedPlanEntity(
    @PrimaryKey val id: String,
    val createdAt: Long,
    val updatedAt: Long,
    val profileJson: String,
    val source: String,
    val sourceLabel: String,
    val revisionNote: String,
    val fallbackNotice: String,
    val disclaimer: String,
    val ideasJson: String
) {
    fun toDomain(): BusinessPlanBundle = BusinessPlanBundle(
        id = id,
        createdAt = createdAt,
        updatedAt = updatedAt,
        profile = PlanJsonCodec.profileFromJsonString(profileJson),
        source = source,
        sourceLabel = sourceLabel,
        revisionNote = revisionNote,
        fallbackNotice = fallbackNotice,
        disclaimer = disclaimer,
        ideas = PlanJsonCodec.ideasFromJson(ideasJson)
    )

    companion object {
        fun fromDomain(bundle: BusinessPlanBundle): SavedPlanEntity = SavedPlanEntity(
            id = bundle.id,
            createdAt = bundle.createdAt,
            updatedAt = bundle.updatedAt,
            profileJson = PlanJsonCodec.profileToJsonString(bundle.profile),
            source = bundle.source,
            sourceLabel = bundle.sourceLabel,
            revisionNote = bundle.revisionNote,
            fallbackNotice = bundle.fallbackNotice,
            disclaimer = bundle.disclaimer,
            ideasJson = PlanJsonCodec.ideasToJson(bundle.ideas)
        )
    }
}
