package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.PlanRepository
import com.example.data.local.AppDatabase
import com.example.ui.AnalysisUiState
import com.example.ui.AppScreen
import com.example.ui.KhatwatViewModel
import com.example.ui.components.KhatwatTopBar
import com.example.ui.components.RevisePlanSheet
import com.example.ui.screens.IdeaDetailScreen
import com.example.ui.screens.LandingScreen
import com.example.ui.screens.QuestionnaireWizardScreen
import com.example.ui.screens.ResultsScreen
import com.example.ui.screens.SavedPlansScreen
import com.example.ui.theme.CanvasOffWhite
import com.example.ui.theme.KhatwatTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        val db = AppDatabase.getInstance(applicationContext)
        val repository = PlanRepository(db.savedPlanDao())

        setContent {
            KhatwatTheme {
                val vm: KhatwatViewModel = viewModel(
                    factory = KhatwatViewModel.Factory(repository)
                )
                KhatwatApp(viewModel = vm)
            }
        }
    }
}

@Composable
fun KhatwatApp(viewModel: KhatwatViewModel) {
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val savedPlans by viewModel.savedPlans.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(Unit) {
        viewModel.snackbarEvents.collect { message ->
            snackbarHostState.showSnackbar(message)
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = CanvasOffWhite,
        contentWindowInsets = WindowInsets(0, 0, 0, 0),
        snackbarHost = { SnackbarHost(hostState = snackbarHostState) },
        topBar = {
            KhatwatTopBar(
                savedCount = savedPlans.size,
                onBrandClick = { viewModel.navigateToLanding() },
                onSavedClick = { viewModel.openSavedPlans() }
            )
        }
    ) { innerPadding ->
        val contentModifier = Modifier
            .fillMaxSize()
            .padding(innerPadding)

        when (uiState.currentScreen) {
            AppScreen.LANDING -> {
                LandingScreen(
                    savedCount = savedPlans.size,
                    onStartWizard = { viewModel.startFreshWizard() },
                    onOpenSaved = { viewModel.openSavedPlans() },
                    modifier = contentModifier
                )
            }

            AppScreen.WIZARD -> {
                QuestionnaireWizardScreen(
                    step = uiState.wizardStep,
                    profile = uiState.profile,
                    errorMessage = uiState.wizardError,
                    useOptionalGemini = uiState.useOptionalGemini,
                    optionalGeminiKey = uiState.optionalGeminiKey,
                    onToggleSkill = viewModel::toggleSkill,
                    onAddCustomSkill = viewModel::addCustomSkill,
                    onRemoveCustomSkill = viewModel::removeCustomSkill,
                    onSelectExperience = viewModel::selectExperience,
                    onToggleInterest = viewModel::toggleInterest,
                    onUpdatePassionNote = viewModel::updatePassionNote,
                    onSelectBudget = viewModel::selectBudget,
                    onUpdateCustomBudget = viewModel::updateCustomBudget,
                    onSelectHours = viewModel::selectHours,
                    onSelectLocation = viewModel::selectLocation,
                    onToggleTool = viewModel::toggleTool,
                    onUpdateCity = viewModel::updateCity,
                    onToggleOptionalGemini = viewModel::setOptionalGemini,
                    onPrevious = viewModel::previousWizardStep,
                    onNext = viewModel::nextWizardStep,
                    onSubmit = { viewModel.submitWizard() },
                    modifier = contentModifier
                )
            }

            AppScreen.RESULTS -> {
                ResultsScreen(
                    analysisState = uiState.analysisState,
                    onOpenIdea = viewModel::openIdeaDetail,
                    onOpenRevise = viewModel::openReviseSheet,
                    onSavePlan = viewModel::saveCurrentPlanExplicitly,
                    onNewAnalysis = viewModel::startFreshWizard,
                    onRetry = { viewModel.submitWizard() },
                    onBackHome = viewModel::navigateToLanding,
                    modifier = contentModifier
                )
            }

            AppScreen.DETAIL -> {
                val bundle = (uiState.analysisState as? AnalysisUiState.Success)?.bundle
                val idea = bundle?.ideas?.find { it.id == uiState.selectedIdeaId }
                    ?: bundle?.ideas?.firstOrNull()
                if (idea != null) {
                    IdeaDetailScreen(
                        idea = idea,
                        selectedTab = uiState.detailTab,
                        onSelectTab = viewModel::selectDetailTab,
                        onToggleStep = { stepId -> viewModel.toggleStepCompletion(idea.id, stepId) },
                        onOpenRevise = viewModel::openReviseSheet,
                        onBack = viewModel::backFromDetailToResults,
                        modifier = contentModifier
                    )
                } else {
                    LandingScreen(
                        savedCount = savedPlans.size,
                        onStartWizard = { viewModel.startFreshWizard() },
                        onOpenSaved = { viewModel.openSavedPlans() },
                        modifier = contentModifier
                    )
                }
            }

            AppScreen.SAVED -> {
                SavedPlansScreen(
                    plans = savedPlans,
                    onOpenPlan = viewModel::openSavedBundle,
                    onDeletePlan = viewModel::deleteSavedPlan,
                    onStartNew = viewModel::startFreshWizard,
                    onBackHome = viewModel::navigateToLanding,
                    modifier = contentModifier
                )
            }
        }
    }

    if (uiState.showReviseSheet) {
        RevisePlanSheet(
            onDismiss = viewModel::dismissReviseSheet,
            onApplyFeedback = viewModel::applyRevisionNote,
            onEditQuestionnaire = viewModel::editQuestionnaireFromRevise
        )
    }
}
